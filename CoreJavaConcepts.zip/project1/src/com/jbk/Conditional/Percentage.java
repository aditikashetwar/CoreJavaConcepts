package com.jbk.Conditional;
import java.util.Scanner;
public class Percentage {
	void per() {
		int p;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your percentage");
		p=sc.nextInt();
		if(p>=75 && p<=100) {
			System.out.println("Distinction");
		}
		else if(p>=60 && p<75) {
			System.out.println("First Class");
		}
		else if(p>=40 && p<60) {
			System.out.println("Second Class");
		}
		else if(p>=40 && p<50) {
			System.out.println("Pass Class");
		}
		else {
			System.out.println("Fail");
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Percentage obj=new Percentage();
		obj.per();

	}

}
