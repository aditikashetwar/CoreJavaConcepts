package com.jbk.Conditional;

import java.util.Scanner;

public class ifDemo {
	void check() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a no.");
		int no=sc.nextInt();
		
		if(no>0) {
			System.out.println("Positive no");
			}
		else if(no<0) {
			System.out.println("negative no");
			}
		else {
			System.out.println("No is zero");
			}
		
	}

	public static void main(String[] args) {
		
		ifDemo obj=new ifDemo ();// object creation and initialization to call the method
		obj.check();

	}

}
