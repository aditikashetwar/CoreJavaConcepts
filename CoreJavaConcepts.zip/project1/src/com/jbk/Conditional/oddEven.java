package com.jbk.Conditional;

public class oddEven {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int no=11;
		if(no%2==0) { //% mod /modulus---- remainder
			System.out.println("Even no");
		}
		else {
			System.out.println("Odd no");
		}

	}

}
