package com.jbk.Conditional;
public class homeWork1 {
	int bill(int prodCost,int quantity) {
		 int bill=prodCost*quantity;
		return bill;// return will be the last statement in the program otherwise it shows error 
	}

	public static void main(String[] args) {
		homeWork1 obj=new homeWork1();
		int bill=obj.bill(500, 2);
		System.out.println("Bill Amt= Rs."+bill);
		if (bill<1000) {
			System.out.println("Add Rs.50 as delivery charges");
			System.out.println("Total Bill Amt= Rs."+(bill+50));
		}
		else if(bill>=1000 && bill<=1500) {
			System.out.println("Add Rs.30 as delivery charges");
			System.out.println("Total Bill Amt= Rs."+(bill+30));
		}
		else {
			System.out.println("Zero delivery charges");
			System.out.println("Total Bill Amt= Rs."+bill);
		}

	}
	

}
