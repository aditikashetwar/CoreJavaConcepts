package com.jbk.Conditional;
import java.util.Scanner;
public class Practice_ {
	int bill(int prodcost,int quant) {
		return prodcost*quant;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Product cost");
		int prodcost=sc.nextInt();
		System.out.println("Enter Quantity");
		int quant=sc.nextInt();
		Practice_ obj=new Practice_();
		obj.bill(prodcost, quant);
		int Amt=obj.bill(prodcost, quant);
		System.out.println("Bill Amount=Rs."+Amt);
		if(Amt<=1000) {
			System.out.println("Add Rs.50 delivery charge");
			System.out.println("Totalbill= Rs."+(Amt+50));
		}
		else if(Amt>1000 && Amt<=1500) {
			System.out.println("Add Rs.30 delivery charge");
			System.out.println("Toatalbill= Rs."+(Amt+30));
		}
		else {
			System.out.println("Zero delivery Charges");
			System.out.println("Totalbill= Rs."+Amt);
		}
	}

}
