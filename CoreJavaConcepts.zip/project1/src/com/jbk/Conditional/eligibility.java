package com.jbk.Conditional;
import java.util.Scanner;
//program to check eligibility criteria-
public class eligibility {
	int per_12, per_grad,apti_mks;
	void getData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 12th Percentage");
		per_12=sc.nextInt();
		System.out.println("Enter Graduation Percentage");
		per_grad=sc.nextInt();
		System.out.println("Enter Aptitude marks");
		apti_mks=sc.nextInt();
	}
	boolean check() {  //new concept
		if(per_12>=90 || per_grad>=80 || apti_mks>=75) {
		return true;}
		else {
			return false;	}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		eligibility obj=new eligibility();
		obj.getData();
boolean g=obj.check();
if (g==true) {
	System.out.println("You are Eligible");
}
else {
	System.out.println("You are not Eligible");
}
	}

}
