package com.jbk.Conditional;

public class nestedIf {

	public static void main(String[] args) {
		int x=10;
		int y=11;
		if(x==10) {
			if(y==10) {
				System.out.println("Both are same variable");
			}
			else {
				System.out.println("Both are not samilar");
			}
		}

	}

}
