package com.jbk.Conditional;

import java.util.Scanner;

public class homeWork2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Coupon code");
		String code=sc.next();
		char ch=code.charAt(0);
		if(ch=='P') {
			System.out.println("You are Eligible for the discount of 20%");
		}
		else if(ch=='M') {
			System.out.println("You are Eligible for the discount of 10%");
		}
		else {
			System.out.println("You are Eligible for the discount of 5%");
		}
		
		
	}

}
