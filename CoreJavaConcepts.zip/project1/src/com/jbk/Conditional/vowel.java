package com.jbk.Conditional;

import java.util.Scanner;
public class vowel {
	void checkVowel() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter character");
		String str=sc.next();
		char ch=str.charAt(0);
		switch(ch) {
		case 'a':
			System.out.println("vowel");
			break;
		case 'e':
			System.out.println("vowel");
			break;
		case 'i':
			System.out.println("vowel");
			break;	
		case 'o':
			System.out.println("vowel");
			break;
		case 'u':
				System.out.println("vowel");
				break;
				default:
					System.out.println("Its not a vowel");
		}
	}

	public static void main(String[] args) {
		vowel v=new vowel();
		v.checkVowel();

	}

}
