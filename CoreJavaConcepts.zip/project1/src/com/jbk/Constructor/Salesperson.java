package com.jbk.Constructor;
//
import java.util.Scanner;
public class Salesperson {
	private int salepersid;
	private String salepersnm;
	private float salepersamt;
	private static float totalsaleAmt=0;
	private static int cnt=0;
	public Salesperson(int salepersid,String salepersnm,float salepersamt){
		this.salepersid=salepersid;
		this.salepersnm=salepersnm;
		this.salepersamt=salepersamt;
		totalsaleAmt=totalsaleAmt+this.salepersamt;
		cnt++;
	}
	static Scanner sc=new Scanner(System.in);
	public void  display() {
		System.out.println("sale person Id="+salepersid);
		System.out.println("sale person name="+salepersnm);
		System.out.println("sale person selling amount="+salepersamt);
	}
	public static void totalsaleAmt() {
		
		System.out.println("Total Sales Amount="+totalsaleAmt);	
	}
	public static void Avg() {
		System.out.println("Average="+totalsaleAmt/cnt);
	}

	public static void main(String[] args) {
		int salepersid;String salepersnm;float salepersamt;
		
		System.out.println("Enter 1st sales person details=Enter id");
		salepersid=sc.nextInt();
		System.out.println("name");
		salepersnm=sc.next();
		System.out.println("Selling Amount");
		salepersamt=sc.nextFloat();
		Salesperson s1=new Salesperson( salepersid, salepersnm, salepersamt);
		
		System.out.println("Enter 2nd sales person details=Enter id");
		salepersid=sc.nextInt();
		System.out.println("name");
		salepersnm=sc.next();
		System.out.println("Selling Amount");
		salepersamt=sc.nextFloat();
		Salesperson s2=new Salesperson( salepersid, salepersnm, salepersamt);
        s1.display();
        s2.display();
        Salesperson.totalsaleAmt();
        Salesperson.Avg();
	}

}
