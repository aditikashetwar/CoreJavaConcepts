package com.jbk.Constructor;

public class Basic {
	int studid;
	String studnm;
	class basic {
		int studid=101;
		String studnm="Aditi";
		}
	void display() {
		System.out.println("Student Id="+studid);
		System.out.println("Student Name="+studnm);
	}
	public static void main(String[] args) {
		Basic b=new Basic();
		b.display();

	}

}
