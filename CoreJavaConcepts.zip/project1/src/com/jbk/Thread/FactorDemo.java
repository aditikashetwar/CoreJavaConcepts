package com.jbk.Thread;

public class FactorDemo extends Thread{
	public void run() {
		for(int i=5;i<=50;i+=5) {
			System.out.println("i="+i);
		}
	}

}
