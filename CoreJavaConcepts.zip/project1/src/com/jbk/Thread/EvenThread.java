package com.jbk.Thread;

public class EvenThread extends Thread{//extends Thread is very important
	public void run() {
		for(int i=2;i<=10;i+=2) {
			System.out.println("Even="+i);
		}
	}

}
