package com.jbk.Thread;

public class MainDemo {

	public static void main(String[] args) {
		ThreadDemo t=new ThreadDemo();
		t.start();//start method is present in the Thread class which we have extends in ThreadDemo
        //Thread is entered into Runnable stage
		//displaying the default name of thread
		System.out.println("Thread Name="+t.getName());
		//displaying default priority
		System.out.println("Thred priority="+t.getPriority());
		t.setName("JBK");
		System.out.println("Thread Name="+t.getName());//changing the name of the thread
		t.setPriority(4);
		System.out.println("Thred priority="+t.getPriority());//changing the priority of the thread
	}

}
