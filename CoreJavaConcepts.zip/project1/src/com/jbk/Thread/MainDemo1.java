package com.jbk.Thread;

public class MainDemo1 {

	public static void main(String[] args) {
		OddThread t1=new OddThread();
		EvenThread t2=new EvenThread();
		 FactorDemo t3=new  FactorDemo();
		 
		 t1.start();
         t2.start();
         t3.start();

	}

}
