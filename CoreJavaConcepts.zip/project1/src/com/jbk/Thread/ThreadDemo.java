package com.jbk.Thread;

public class ThreadDemo extends Thread{//extends Thread is very important
	public void run() {
		for(int i=0;i<=5;i++) {
		System.out.println("i="+i);
	}
		}

}
