package com.jbk.whileLoop;
//Program to print factorial of no.
import java.util.Scanner;
public class Factorial {
	void fact(int no) {
		int i=1;
		int f=1;
		while(i<=no) {
			f=f*i;
			i++;
		}
		System.out.println(f);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter no");
		int no=sc.nextInt();
		Factorial f=new Factorial();
		f.fact(no);
	}

}
