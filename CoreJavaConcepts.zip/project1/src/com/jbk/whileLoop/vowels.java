package com.jbk.whileLoop;

import java.util.Scanner;

//Program to count VOWELS of string
public class vowels {
	void count() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		String s=sc.nextLine();
		int cnt=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='a' || s.charAt(i)=='e' ||s.charAt(i)=='i' ||s.charAt(i)=='o' || s.charAt(i)=='u' )
					{
				cnt++;
					}
		}
		System.out.println(cnt);
	}

	public static void main(String[] args) {
		vowels v=new vowels();
		v.count();
		

	}

}
