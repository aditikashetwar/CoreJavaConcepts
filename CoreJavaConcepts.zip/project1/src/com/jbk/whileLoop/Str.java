package com.jbk.whileLoop;
//Program to print each character of a string 
import java.util.Scanner;
public class Str {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String value");
		String s=sc.nextLine();
		for(int i=0;i<s.length();i++) {
			System.out.println(s.charAt(i));
		}
		
		

	}

}
