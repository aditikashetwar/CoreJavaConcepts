package com.jbk.ExceptionHandling;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Nested_try {
	static Scanner sc=new Scanner(System.in);
	void check() {
		int arr[]= {10,8,7,6,5};
		try {
			System.out.println("Enter the index of element u hv to print");
			int index=sc.nextInt();
			System.out.println("Array index="+arr[index]);
			//inner try block
			try {
				System.out.println("Enter two nos");
				int no=sc.nextInt();
				int no1=sc.nextInt();
				System.out.println("Ans="+no/no1);
			}
			//inner catch block
			catch(ArithmeticException e) {
				System.out.println("cannot divide the no by zero");
			}
		}//Outer try block ends
		catch(InputMismatchException e) {
			System.out.println("Enter only integers");	
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("u hv exceeded the array limit");
		}
	}
	public static void main(String[] args) {
		Nested_try obj=new Nested_try();
		obj.check();

	}

}
