package com.jbk.ExceptionHandling;

public class AgeExpection extends Exception {
	public AgeExpection(String s) {
		super(s);
		
	}

}
