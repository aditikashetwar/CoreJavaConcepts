package com.jbk.ExceptionHandling;

public class TestEx1 {
	void check() {
		int num1,num2;
		try {
			num1=0;
			num2=12/num1;
			System.out.println("Try block message");
		}catch(ArithmeticException  e) {
			System.out.println("Error:Don't divide a no by zero");
		}
		System.out.println("I am out of try catch block");
	}

	public static void main(String[] args) {
		
		TestEx1 obj=new TestEx1 ();
		obj.check();
	}

}
