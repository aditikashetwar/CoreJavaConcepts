package com.jbk.ExceptionHandling;
import java.util.Scanner;
import  java.util.InputMismatchException;
public class MultiCatch {
	static Scanner sc=new Scanner(System.in);
	void check() {
		int arr[]= {10,20,30,40};
		try {
		System.out.println("Enter index of element u want to print");
		int index=sc.nextInt();
		System.out.println("Array Element="+arr[index]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(" u hv exceeded the array limit");
		}
		catch(InputMismatchException e) {
			System.out.println("Enetr only integer");
		}
	}
	

	public static void main(String[] args) {
		MultiCatch obj=new MultiCatch();
		obj.check();

	}

}
