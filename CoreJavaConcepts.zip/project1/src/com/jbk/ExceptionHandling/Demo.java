package com.jbk.ExceptionHandling;
import java.util.Scanner;
public class Demo {
	void demo() {
		int arr[]= {6,7,8,9,10};
		//try block
		//Statement which will throw the error/exception
		try {
		System.out.println(arr[5]);
		}
		catch (ArrayIndexOutOfBoundsException e){
			System.out.println("u have exceeded the array limit");
		}
		//catch block 
		//Handles the exception
		finally {
			System.out.println("I am in finally");
		}
		//finally block always be executed whether the error will occur or not
	}

	public static void main(String[] args) {
		Demo obj=new Demo();
		obj.demo();

	}

}
