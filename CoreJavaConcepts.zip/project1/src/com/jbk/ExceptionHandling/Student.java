package com.jbk.ExceptionHandling;
import java.util.Scanner;
import java.util.InputMismatchException;
//User defined/Custom Exception;
public class Student {
	static Scanner sc=new Scanner(System.in);
	void Agecheck() {
		try {
			System.out.println("Enter Age");
			int age=sc.nextInt();
			if(age>18) {
				System.out.println("Valid Age");
			}else {
				throw new AgeExpection("Age cannot be less than 18");
			
		}
			}
			catch(AgeExpection e){
				System.out.println(e.getMessage());
				}
		catch(InputMismatchException e) {
			System.out.println("cannot be a character");
		}
	}
	public static void main(String[] args) {
		Student obj=new Student();
		obj.Agecheck();
	}

}
