package com.jbk.Inheritance;

public class Inheritance {

	public static void main(String[] args) {
		
		B obj=new B();
		obj.i=1;
		obj.j=2;
		
		obj.m1();
		
	}

}
