package com.jbk.Inheritance;

public class Manager1 extends Employee1 {
	protected float bonus;

	public float getBonus() {
		return bonus;
	}

	public void setBonus(float bonus) {
		this.bonus = bonus;
	}
	public void totalsal() {
		super.totalsal();
System.out.println("Total Salary of Manager="+(Empsalary+bonus));
	}

}
