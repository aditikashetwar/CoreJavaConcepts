package com.jbk.Inheritance;

public abstract class Product {
	public abstract void bill(int qty);
}
