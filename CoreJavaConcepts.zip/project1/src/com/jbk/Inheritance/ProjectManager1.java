package com.jbk.Inheritance;

public class ProjectManager1 extends Manager1{
	private String Projnm;
	private float Projallow;
	public String getProjnm() {
		return Projnm;
	}
	public void setProjnm(String projnm) {
		Projnm = projnm;
	}
	public float getProjallow() {
		return Projallow;
	}
	public void setProjallow(float projallow) {
		Projallow = projallow;
	}
	public void totalsal() {
		super.totalsal();
      System.out.println("Total Sal="+(Empsalary+bonus+Projallow));
	}

}
