package com.jbk.Inheritance;

public class B extends A{
	
	int j;
	void m1() {
		super.i=j+1;
		System.out.println(j+" "+i);
		
	}

	public static void main(String[] args) {
		B obj=new B();
		obj.i=1;
		obj.j=2;
		
		obj.m1();
		
	}

}
