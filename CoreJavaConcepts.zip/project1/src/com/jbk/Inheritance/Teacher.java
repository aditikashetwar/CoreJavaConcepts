package com.jbk.Inheritance;
//we can achieve constructor overloading by changing passing parameters
public class Teacher {
	int salary;
	Teacher(){
		System.out.println("welcome");
	}
	Teacher(int salary){
		this.salary=salary;
	}

}
