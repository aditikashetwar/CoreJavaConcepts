package com.jbk.Inheritance;

public class MarketManager extends Manager1{
	private String Mktprojnm;
	private float Mktprojallow;
	public String getMktprojnm() {
		return Mktprojnm;
	}
	public void setMktprojnm(String mktprojnm) {
		Mktprojnm = mktprojnm;
	}
	public float getMktprojallow() {
		return Mktprojallow;
	}
	public void setMktprojallow(float mktprojallow) {
		Mktprojallow = mktprojallow;
	}
	public void totalsal() {
		super.totalsal();
System.out.println("Total Salary of Marketing Manager="+(Empsalary+bonus+Mktprojallow));
	}

}
