package com.jbk.Inheritance;


public class A {
	int i;
	void m1() {
		System.out.println(i);
	}

}
