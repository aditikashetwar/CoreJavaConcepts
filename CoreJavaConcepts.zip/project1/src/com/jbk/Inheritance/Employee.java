package com.jbk.Inheritance;
//It is Base class so we can not use main Method
public class Employee {
	protected int employeeId;
	protected String employeeNm;
	protected float employeeSal;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeNm() {
		return employeeNm;
	}

	public void setEmployeeNm(String employeeNm) {
		this.employeeNm = employeeNm;
	}

	public float getEmployeeSal() {
		return employeeSal;
	}

	public void setEmployeeSal(float employeeSal) {
		this.employeeSal = employeeSal;
	}

}