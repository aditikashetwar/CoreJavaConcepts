package com.jbk.Inheritance;
import java.util.Scanner;
public class Maindemo {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		Manager m1=new Manager();
		System.out.println("Enter employee id");
		int id=sc.nextInt();
		m1.setEmployeeId(id);
		
		System.out.println("Enter employee Name");
		String name=sc.next();
		m1.setEmployeeNm(name);
		
		System.out.println("Enter employee Salary");
		float salary=sc.nextFloat();
		m1.setEmployeeSal(salary);
		
		System.out.println("Enter bonus");
		float bonus=sc.nextFloat();
		m1.setBonus(bonus);
		
		System.out.println("Enter Employee Details");
		System.out.println("id="+m1.getEmployeeId());
		System.out.println("Name="+m1.getBonus());
		System.out.println("Salary="+m1.getEmployeeSal());
		System.out.println("Bonus="+m1.getBonus());
		m1.total();		

	}

}
