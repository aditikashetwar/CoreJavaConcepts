package com.jbk.Inheritance;

public class child extends Parent {
	child(int x){
		super(10,20);
		System.out.println(x);
	}

	
}
