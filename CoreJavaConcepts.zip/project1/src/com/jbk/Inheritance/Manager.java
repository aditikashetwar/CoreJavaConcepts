package com.jbk.Inheritance;
//Manager class inheriting the employee class(Single level inheritance)
public class Manager extends Employee{

	private float bonus;

	public float getBonus() {
		return bonus;
	}

	public void setBonus(float bonus) {
		this.bonus = bonus;
	}
	public void total() {
		System.out.println("Total Salary="+(bonus+employeeSal));
	}
}
