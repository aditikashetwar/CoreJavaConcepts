package com.jbk.Inheritance;

public class Employee1 {
	private int Empid;
	private String Empnm;
	protected float Empsalary;
	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getEmpnm() {
		return Empnm;
	}
	public void setEmpnm(String empnm) {
		Empnm = empnm;
	}
	public float getEmpsalary() {
		return Empsalary;
	}
	public void setEmpsalary(float empsalary) {
		Empsalary = empsalary;
	}
	public void totalsal() {
		System.out.println("Total sal of Employee="+Empsalary);
	}

}
