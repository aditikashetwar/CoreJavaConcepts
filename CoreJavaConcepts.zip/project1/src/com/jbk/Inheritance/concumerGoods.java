package com.jbk.Inheritance;

public class concumerGoods extends Product{
	final int prod1cost=9000;

	
	public void bill(int qty) {
	System.out.println("Total cost="+(qty*prod1cost));
		
	}
	

}
