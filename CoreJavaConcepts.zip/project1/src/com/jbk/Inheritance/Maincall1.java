package com.jbk.Inheritance;
import java.util.Scanner;
//Hirarchical Inheritance
//creating a reference of child class and calling parent class and child class methods
public class Maincall1 {
      static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		ProjectManager1 m1=new ProjectManager1();
		//Acceppting the data from user
		System.out.println("Details of Project Manager");
		System.out.println("Enter Employee Id");
		int id=sc.nextInt();
		m1.setEmpid(id);
		System.out.println("Enter Employee Name");
		String nm=sc.next();
		m1.setEmpnm(nm);
		System.out.println("Enetr Employee Salry");
		float sal=sc.nextFloat();
		m1.setEmpsalary(sal);
		System.out.println("Enetr emp bonus");
		float bonus=sc.nextFloat();
		m1.setBonus(bonus);
		System.out.println("Enetr Project Name");
		String pronm=sc.next();
		m1.setProjnm(pronm);
		System.out.println("Enetr Project Allowance");
		float proallow=sc.nextFloat();
		m1.setProjallow(proallow);
		
		//Displaying the Project Manager Details
		System.out.println("Employee Id="+m1.getEmpid());
		System.out.println("Employee Name="+m1.getEmpnm());
		System.out.println("Employee Salary="+m1.getEmpsalary());
		System.out.println("Employee Bonus="+m1.getBonus());
		System.out.println("Employee Project Name"+m1.getProjnm());
		System.out.println("Project Allowance="+m1.getProjallow());
		m1.totalsal();
		
		MarketManager mk1=new MarketManager();
		//Accepting data for market manager from user
		System.out.println("Market Manager Details");
		System.out.println("Enter Employee Id");
		int mkid=sc.nextInt();
		mk1.setEmpid(mkid);
		System.out.println("Enter Employee Name");
		String Name=sc.next();
		mk1.setEmpnm(Name);
		System.out.println("Enetr Employee Salary");
		float Sal=sc.nextFloat();
		mk1.setEmpsalary(Sal);
		System.out.println("Enetr Employee Bonus");
		float bonus1=sc.nextFloat();
		mk1.setBonus(bonus1);
		System.out.println("Enetr Market project Name");
		String projnm=sc.next();
		mk1.setMktprojnm(projnm);
		System.out.println("Enetr allowance");
		float mkprojallow=sc.nextFloat();
		mk1.setMktprojallow(mkprojallow);
		//Displaying the details of Market Manager
		System.out.println("Employee Name="+mk1.getEmpnm());		
		System.out.println("Employee Id="+mk1.getEmpid());
		System.out.println("Employee Salary="+mk1.getEmpsalary());
		System.out.println("Employee Bonus="+mk1.getBonus());
		System.out.println("Market Project Name="+mk1.getMktprojnm());
		System.out.println("Market Project Allowance="+mk1.getMktprojallow());
		mk1.totalsal();
		
	

	}

}
