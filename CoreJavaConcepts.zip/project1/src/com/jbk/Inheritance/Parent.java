package com.jbk.Inheritance;

public class Parent {
	Parent(int a,int b){
		int z=a+b;
		System.out.println("sum="+z);
	}

}
