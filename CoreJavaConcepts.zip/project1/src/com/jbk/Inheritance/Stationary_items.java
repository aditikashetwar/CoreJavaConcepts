package com.jbk.Inheritance;

public class Stationary_items extends Product {
    final int stat2item=900;
    public void bill(int qty) {
    	System.out.println("Total Bill="+(qty*stat2item));
    }
}
