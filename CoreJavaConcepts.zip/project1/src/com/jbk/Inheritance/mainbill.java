package com.jbk.Inheritance;
import java.util.Scanner;
public class mainbill {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 for consumer goods and 2 for stationary items");
        int choice=sc.nextInt();
        switch(choice) {
        case 1:
        	System.out.println("Enter quantity");
        	int qty=sc.nextInt();
        	Product gd=new concumerGoods();
        	gd.bill(qty);
        	break;
        case 2:
        	System.out.println("Enter Quantity");
        	int qty1=sc.nextInt();
        	Product gd1=new Stationary_items();
        	gd1.bill(qty1);
        	break;
        	default:
        		System.out.println("Invalid choice");
        }
	}

}
