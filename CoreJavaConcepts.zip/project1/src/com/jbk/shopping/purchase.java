package com.jbk.shopping;
import com.jbk.Encapsulation.product;
import java.util.Scanner;
//data variable declared as private and access in different package and same class
public class purchase {
	void bill(int qt,float cost) {
		System.out.println("bill amt="+(cost*qt));
	}
static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter product id");
		int id=sc.nextInt();
		System.out.println("Enter product cost");
		float cost=sc.nextFloat();
		System.out.println("Enetr quantity");
		int qt=sc.nextInt();
		System.out.println("Enter product name");
		String nm=sc.next();
		product obj=new product();
		obj.setProid(id);
		obj.setProdcost(cost);
		obj.setProdnm(nm);
		purchase p=new purchase();
	p.bill(qt, cost);
	}

}
