package com.jbk.shopping;
//Data variables are declared private and access in different package & different class
import com.jbk.Encapsulation.product;
import java.util.Scanner;
public class purchase1 {
	void bill(int qt,float cost) {
		System.out.println("bill amt="+(cost*qt));
	}
    static Scanner sc=new Scanner (System.in);
	public static void main(String[] args) {
		System.out.println("Enter product id");
		int id=sc.nextInt();
		System.out.println("Enter product cost");
		float cost=sc.nextFloat();
		System.out.println("Enetr quantity");
		int qt=sc.nextInt();
		System.out.println("Enter product name");
		String nm=sc.next();
		product obj=new product();
		obj.setProid(id);
		obj.setProdcost(cost);
		obj.setProdnm(nm);
		purchase1 p=new purchase1();
	p.bill(qt, cost);

	}

}
