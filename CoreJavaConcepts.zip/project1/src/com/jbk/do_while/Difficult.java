package com.jbk.do_while;
import java.util.Scanner;
public class Difficult {
	int no,no1;
	void setData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no");
		no=sc.nextInt();
		System.out.println("Enetr no1");
	    no1=sc.nextInt();
	}
	void add() {
		System.out.println("add= "+(no+no1));
	}
	void diff() {
		System.out.println("Diff= "+(no-no1));
	}
	public static void main(String[] args) {
		int choice1;
		Difficult obj=new Difficult();
		obj.setData();
        System.out.println("Enter ur choice 1.add , 2.diff");
        Scanner s=new Scanner(System.in);
        int choice=s.nextInt();
        
        switch(choice) {
        case 1:
	    obj.add();
	    break;
        case 2:
        obj.diff();
        break;
        default:
        System.out.println("Invalid choice");
     }
        System.out.println("Enter ur choice 1-continue,0-Break");
        choice1=s.nextInt();	
        s.close();
	 }
}

