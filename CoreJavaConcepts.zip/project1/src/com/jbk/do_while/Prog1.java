package com.jbk.do_while;

import java.util.Scanner;

public class Prog1 {

	public static void main(String[] args) {
	int n;
	do {
		System.out.println("Hello");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 to continue else enter 0");
		n=sc.nextInt();
		
	}while(n==1);
	

	}

}
