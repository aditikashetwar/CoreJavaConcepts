package com.jbk.do_while;

public class Basic {

	public static void main(String[] args) {
		int i=1;
		int f=1;
		do {
			System.out.println("i= "+i);
			System.out.println("Hello");
              i++;
		}while(i<=5);
		
		
			

	}

}
