package com.jbk.do_while;
import java.util.Scanner;
public class menuDriven {
	int no,no1;
	Scanner sc=new Scanner(System.in);
	void setData() {
		System.out.println("Enter no");
		no=sc.nextInt();
		System.out.println("Enter no1");
		no1=sc.nextInt();
	}
	void add() {
		System.out.println("Add= "+(no+no1));
	}
	void diff() {
		System.out.println("Diff= "+(no-no1));
	}

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);	
	menuDriven obj=new menuDriven();
    int choice1;
    do {
	System.out.println("enter your choice 1.Add,2.Diff");
	int choice=sc.nextInt();
	
		switch(choice) {
		case 1:
	   obj.setData();
       obj.add();
       break;
		case 2:
	   obj.setData();
       obj.diff();
       break;
       default:
    	   System.out.println("Invalid choice ");
		}
       System.out.println("Enter ur choice 1-continue,0-Break");
       choice1=sc.nextInt();	
		}
    while(choice1==1);
	
	}
}