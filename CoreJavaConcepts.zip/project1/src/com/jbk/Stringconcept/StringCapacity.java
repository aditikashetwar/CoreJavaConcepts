package com.jbk.Stringconcept;
import java.util.Scanner;
public class StringCapacity {
	static Scanner sc=new Scanner(System.in);
	void capacity() {
		System.out.println("Enetr fnm");
		String s=sc.next();
		StringBuffer s1=new StringBuffer();//
		//here in string buffer s1 ,string s is not stored.
		//so its giving a default capacity as 16
		System.out.println("Capacity="+s1.capacity());
		s1=new StringBuffer(s);//here in string buffer s is stored 
		//so its giving capacity 16+string count
		System.out.println("capacity="+s1.capacity());
	}

	public static void main(String[] args) {
		StringCapacity obj=new StringCapacity();
		obj.capacity();

	}

}
