package com.jbk.Stringconcept;
import java.util.Scanner;
//we use append method to add at last and insert method to insert word in between the word 
public class StringBufferMethod {
	static Scanner sc=new Scanner(System.in);
	void BufferMethod() {
		System.out.println("Enter first name");
		String fnm=sc.next();
		StringBuffer firstnm=new StringBuffer(fnm);
		System.out.println("Enter last name");
		String lnm=sc.next();
		StringBuffer lastnm=new StringBuffer(lnm);
		System.out.println(firstnm.append(" "+lastnm));
		System.out.println("Hello "+firstnm);
		System.out.println(firstnm.delete(3, 5));
		System.out.println(firstnm.insert(3,"tai"));
		StringBuffer s1=new StringBuffer(firstnm);
		System.out.println(firstnm.reverse());
		if(s1.equals(firstnm)) {//here in s1 firstnm means Aditai kashetwar is present,but 
			System.out.println("Equals");//but equals of firstnm reverse of this present ,so
		}                            //so it is not equals 
			else{
			System.out.println("Not Equals");
		}
	}

	public static void main(String[] args) {
		StringBufferMethod obj=new StringBufferMethod();
		obj.BufferMethod();

	}

}
