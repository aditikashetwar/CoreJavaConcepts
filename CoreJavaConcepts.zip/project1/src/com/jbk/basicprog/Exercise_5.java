package com.jbk.basicprog;

public class Exercise_5 {
	public static void main(String[] args) {
		double b=45.76;
		char c='T';
		boolean e=true;
		System.out.println("Double "+b);
		System.out.println("Character "+c);
		System.out.println("Boolean "+e);
		
	}

}
