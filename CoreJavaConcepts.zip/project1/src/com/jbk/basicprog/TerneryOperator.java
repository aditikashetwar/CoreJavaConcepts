package com.jbk.basicprog;
import java.util.Scanner;
//program to find whether the first character of sentence is uppercase or lowercase;
public class TerneryOperator {
    static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
		System.out.println("Enter sentence");
		char z=sc.next().charAt(0);
		String  Alphabet = z>=65 && z<=95 || z>=98 && z<=112?"It is in uppercase":"It is lowercase";
		System.out.println(Alphabet);
	}

}
