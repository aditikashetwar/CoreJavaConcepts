package com.jbk.basicprog;

public class Area {
	public static void main(String[] args) {
		System.out.println("Hello");//print statement and then it take a new line.
		System.out.print("Welcome to jbk");
		System.out.println("java");
		System.out.println("Hello"+" "+"All");
		System.out.println(100);
		int a=100,b=1,c=3,d=5;
		System.out.println(a*a);
		System.out.println(a/a);
		System.out.println(a+b+c+d);
		System.out.println(b*c*d);
		System.out.println("Square of a no 3 is"+ c*c);
	}

}
