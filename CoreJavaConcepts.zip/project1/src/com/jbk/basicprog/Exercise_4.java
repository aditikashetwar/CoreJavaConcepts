package com.jbk.basicprog;

public class Exercise_4 {

	public static void main(String[] args) {
		int a=10;
		System.out.println(a);
		a=a+10;
		System.out.println(a);
		a=a*10;
		System.out.println(a);
		a=a/10;
		System.out.println(a);
		a=a-10;
		System.out.println(a);
		// TODO Auto-generated method stub

	}

}
