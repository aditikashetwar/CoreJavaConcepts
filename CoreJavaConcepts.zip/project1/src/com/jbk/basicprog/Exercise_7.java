package com.jbk.basicprog;

public class Exercise_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2;
		num1=22;
		num2=8;
		System.out.println(num1+"+"+num2+"="+(num1+num2));
		System.out.println(num1+"-"+num2+"="+(num1-num2));
		System.out.println(num1+"*"+num2+"="+(num1*num2));
		System.out.println(num1+"/"+num2+"="+(num1/num2));
		System.out.println(num1+"mod"+num2+"="+(num1%num2));
		

	}

}
