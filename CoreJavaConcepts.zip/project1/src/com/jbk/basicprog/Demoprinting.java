package com.jbk.basicprog;

public class Demoprinting {

	public static void main(String[] args) {
		System.out.println("Java by kiran");
		System.out.println("Karve Nagar");
		System.out.println(3);
		System.out.println(3+4);
		System.out.println(3-4);
		System.out.println(3/4);
		System.out.println(3*4);
		
		
	}

}
