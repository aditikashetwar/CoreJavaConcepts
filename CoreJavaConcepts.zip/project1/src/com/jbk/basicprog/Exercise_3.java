package com.jbk.basicprog;



public class Exercise_3 {

	
	
	public static void main(String[] args) {
		System.out.println("3/2 ="+(3/2));
		System.out.println("3/2 ="+(3/2.0));
		System.out.println("3/2 ="+(3.0/2));
		System.out.println("3/2 ="+(3.0/2.0));
		// TODO Auto-generated method stub

	}

}
