package com.jbk.basicprog;
import java.util.Scanner;
public class TerneryOperator1 {
    static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter no u want check whether it is odd or even");
		int no=sc.nextInt();
		String no1=no%2==0 ? "It is Even no": "It is odd no";
		System.out.println(no1);

	}

}
