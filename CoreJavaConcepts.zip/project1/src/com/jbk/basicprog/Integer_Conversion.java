package com.jbk.basicprog;
import java.util.Scanner;
public class Integer_Conversion {

	public static void main(String[] args) {
		int no;
		byte b;
		char c;
		float d;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter integer value");
		no=sc.nextInt();
		b=(byte)no;//type casting as we hv written in bracket byte as a type of datatype
		System.out.println("Conversion into byte="+b);
		c=(char)no;//it will done explicitly
		System.out.println("Conversion into char="+c);
		d=no;
		System.out.println("Conversion into float="+d);
	
		int v=b;//it is done implicitly as int is higher than byte ,so is done automatically
		System.out.println();

	}

}
