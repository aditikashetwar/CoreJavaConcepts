package com.jbk.basicprog;
public class Ternary_Operator {

	public static void main(String[] args) {
		byte b=0;
		
		boolean b1=true;
		int v=(b1)?1:0;//ternary operator
		//if b1 is true then it will display 1 else it will display 0
		System.out.println(v);
		
		int age=16;
		String res=age>=18?"You are eligible for driving lisence":"u are not eligible";
		//if age>=18 then res will store 1 else it will store 0
		System.out.println(res);
		
		//if u want to print statement as "u are not eligible" then for res u hv to use String datatype
	}

}
