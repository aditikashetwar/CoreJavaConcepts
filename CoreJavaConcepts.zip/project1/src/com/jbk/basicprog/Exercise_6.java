package com.jbk.basicprog;

public class Exercise_6 {

	public static void main(String[] args) {
		int x=5,y=2;
		System.out.println("x");
		System.out.println("y");
		System.out.println("x+y");
		System.out.println(x);
		System.out.println(y);
		System.out.println(x+y);
		// TODO Auto-generated method stub

	}

}
