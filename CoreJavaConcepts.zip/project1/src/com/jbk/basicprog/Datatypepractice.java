package com.jbk.basicprog;

public class Datatypepractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float n1=56.78f,n2=87.65f,n3=43.76f;//Avg of 3 floats
		float Avg=(n1+n2+n3)/3;
		System.out.println(Avg);
		
		float proRate=500.50f;//make bill
		int proQuantity=3;
		double bill=proRate*proQuantity;
		System.out.println("proRate="+proRate+"\nproQuantity="+proQuantity+"\nTotal Bill="+bill);

		double no1=78.5;//product of 2 double
		double no2=45.5;
		double product=no1*no2;
		System.out.println(product);
		
		float quotient=n2/n1;//divide 2 floats
		System.out.println(quotient);
		
		char ch='R';//Display char and String
		char mh='Y';
		char nh='T';
		
		String myName="Aditi Kashetwar";
		
		System.out.println(ch);
		System.out.println(mh);
		System.out.println(nh);
		System.out.println(myName);
				
	}

}
