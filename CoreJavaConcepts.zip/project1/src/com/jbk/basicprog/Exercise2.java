package com.jbk.basicprog;

public class Exercise2 {

	public static void main(String[] args) {
		int num;
		float f;
		char c;
		double b;
		String s;
		num=80;
		f=4.65f;
		c='y';
		b=54.87;
		s="My name is Aditi";
		System.out.println("Value of num is:"+num);
		System.out.println("value of c is:"+c);
		System.out.println("Value of f is:"+f);
		System.out.println("string is : "+s);
		System.out.println("Value of b is: "+b);
		
		// TODO Auto-generated method stub

	}

}
