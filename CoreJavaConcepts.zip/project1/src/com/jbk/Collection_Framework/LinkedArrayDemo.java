package com.jbk.Collection_Framework;
import java.util.LinkedList;
import java.util.Scanner;
public class LinkedArrayDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many array elements u wants");
		int n=sc.nextInt();
		LinkedList<Integer> a=new LinkedList();//here only u hv to write Wrapper class
		
		System.out.println("Enter integers");
		for(int i=0;i<n;i++) {
			a.add(sc.nextInt());
		}
		System.out.println(a);
		for(Integer g:a) {       //printing of Array elements using for-each loop
			System.out.println(g);
		}
		
	}

}
