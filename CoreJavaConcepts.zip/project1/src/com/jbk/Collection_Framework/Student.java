package com.jbk.Collection_Framework;

public class Student {
	int sid;
	String snm;
	public Student(int sid,String snm) {
		this.sid=sid;
		this.snm=snm;
	}
	
}
