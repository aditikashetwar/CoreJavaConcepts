package com.jbk.Collection_Framework;
import java.util.ArrayList;
import java.util.Scanner;
public class ArrayListDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		ArrayList<String> a=new ArrayList();//Storing String Objects
		for(int i=0;i<5;i++) {//Adding 5 Strings into Array List
			System.out.println("Enter a String");
			a.add(sc.nextLine());
		}
		System.out.println(a);
		a.remove(0);
		System.out.println(a);
		a.add("MYSQL");
		System.out.println(a);
		a.add("Oracle");
		System.out.println(a);
		
		
		//Displaying the Elements in array list
		for(String s:a) {     //by using for each loop
			System.out.println(s);
		}
	}
	}


