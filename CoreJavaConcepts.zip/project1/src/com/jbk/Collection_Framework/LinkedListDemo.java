package com.jbk.Collection_Framework;
import java.util.Scanner;
import java.util.LinkedList;
import java.util.Iterator;
public class LinkedListDemo {

	public static void main(String[] args) {
		LinkedList<String> arr1=new LinkedList<>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Add City");
		String c=sc.next();
		arr1.add(c);
		arr1.add("Mumbai");
		Iterator<String> itr=arr1.iterator();
		while(itr.hasNext()) //here it will give true or false
		{
			System.out.println(itr.next());
		}

	}

}
