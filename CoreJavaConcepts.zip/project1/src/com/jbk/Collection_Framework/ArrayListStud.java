package com.jbk.Collection_Framework;
import java.util.Iterator;
//Added the student reference to the ArrayList;
import java.util.ArrayList;
public class ArrayListStud {
	public static void main(String[] args) {
		ArrayList<Student>arr1=new ArrayList<Student>();
		//here we are storing student elements in the array list
		Student s=new Student(1,"Aditi");
		Student s1=new Student(2,"Sarika");
		arr1.add(s);
		arr1.add(s1);
		for(Student obj:arr1) {
			System.out.println(obj.sid);
			System.out.println(obj.snm);
		}
		arr1.remove(0);
		System.out.println("After removing");
		for(Student obj:arr1) {
			System.out.println(obj.sid);
			System.out.println(obj.snm);
		}
		arr1.add(new Student(3,"Adi"));
		System.out.println("After Adding");
		for(Student obj:arr1) {
			System.out.println(obj.sid);
			System.out.println(obj.snm);
		}
		arr1.add(1,new Student(4,"Dipa"));
		System.out.println("After insertion");
		for(Student obj:arr1) {
			System.out.println(obj.sid);
			System.out.println(obj.snm);
		}
	}

}
