package com.jbk.Collection_Framework;
//Adding Elements in Hashset;
import java.util.HashSet;
public class HashsetDemo {

	public static void main(String[] args) {
		HashSet<String> hs=new HashSet<>();
		hs.add("B");
		hs.add("AA");
		hs.add("K");
		hs.add("M");
		hs.add("MKL");
		hs.add("Z");
		hs.add("Pune");
		hs.add("Delhi");
		hs.add("AAA");
		hs.add("AA");
		System.out.println("First Hashset:="+hs);

	}

}
