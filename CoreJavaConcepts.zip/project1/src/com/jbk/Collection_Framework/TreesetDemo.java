package com.jbk.Collection_Framework;
import java.util.TreeSet;
public class TreesetDemo {

	public static void main(String[] args) {
		TreeSet<String> tr=new TreeSet<>();
		tr.add("A");
		tr.add("Z");
		tr.add("MAA");
		tr.add("ZA");
		tr.add("MPL");
		tr.add("BAG");
		tr.add("ZP");
		tr.add("AAA");
		System.out.println("First Treeset:="+tr);

	}

}
