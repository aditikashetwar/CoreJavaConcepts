package com.jbk.Collection_Framework;
import java.util.Vector;
public class VectorDemo {

	public static void main(String[] args) {
		Vector v=new Vector();
		v.add("JBK");
		v.add("JAVA");
		v.add(0,"123");
		System.out.println("capacity="+v.size());
		System.out.println(v);	
	}
}
