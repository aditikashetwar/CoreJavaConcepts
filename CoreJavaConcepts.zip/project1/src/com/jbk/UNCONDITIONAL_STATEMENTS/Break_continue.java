package com.jbk.UNCONDITIONAL_STATEMENTS;

public class Break_continue {
	public static void main(String[] args) {
		int n=12;
		for(int i=1;i<n;i++) {
			if(i%2==0) {
				System.out.println(i+"Next to continue");
				continue;// it will only goes into loop	
			}
			else if(i==5) {
				System.out.println("i is 5");
				break;//it will come out from for loop
			}
			System.out.println("ok"+i);
		}
		System.out.println("Done");

	}

}
