package com.jbk.Polymorphism;
//Method Overloading
public class AddOverload {
	void sum(int no,int no1) {
		System.out.println(no+no1);
	}
	void sum(int no,int no1,int no2) {
		System.out.println(no+no1+no2);
	}
	void sum(double no,double no1) {
		System.out.println(no+no1);
	}
	void sum(double no,double no1,double no2) {
		System.out.println(no+no1+no2);
	}
	void sum(float no,double no1) {
		System.out.println(no+no1);
	}

	public static void main(String[] args) {
		AddOverload obj= new AddOverload();
		obj.sum(7, 6);
		obj.sum(3, 5, 7);
		obj.sum(43.65,87.65,54.76);
		obj.sum(45.76, 65.0);
		obj.sum(65.7f,54.70);

	}

}
