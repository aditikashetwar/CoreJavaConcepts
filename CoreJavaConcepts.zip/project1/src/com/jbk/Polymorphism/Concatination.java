package com.jbk.Polymorphism;
import java.util.Scanner;
public class Concatination {
//Constructor overloading
	static Scanner sc=new Scanner (System.in);
	Concatination(String course){
	System.out.println("Course name - "+course);	
	}
	Concatination(String fnm,String lnm){
		System.out.println("Welcome- "+fnm+" "+lnm);
	}
	Concatination(String country,String state,String city){
		System.out.println("Welcome to -"+country+"-"+state+"-"+city);
	}
	public static void main(String[] args) {
		System.out.println("Enter course name");
		String cnm=sc.next();//with scanner example
		Concatination obj=new Concatination(cnm);
		Concatination obj1=new Concatination("Aditi","Kashetwar");
		Concatination obj2=new Concatination("India","Maharashtra","Pune");

	}

}
