package com.jbk.Array;
//Program to accept 3 string in an array and also accept the string to be search
//if the string is found then display found otherwise display NF
import java.util.Scanner;
import java.util.Arrays;
public class StringArray {
	static Scanner sc=new Scanner (System.in);
	String a[]=new String[3];
	void check() {
		System.out.println("Enetr 3 string Elements");
		for (int i=0;i<3;i++) {
			a[i]=sc.next();	
		}
		System.out.println("Enter the name to search");
		String nm=sc.next();
		//Arrays.sort(a);
		System.out.println("Element position="+Arrays.binarySearch(a, nm));
		int n=Arrays.binarySearch(a,nm);
		
		if(n>=0) {
			System.out.println("Found");
		}else {
			System.out.println("NF");
		}
	}
	

	public static void main(String[] args) {
		StringArray s=new StringArray();
		s.check();
	}

}
