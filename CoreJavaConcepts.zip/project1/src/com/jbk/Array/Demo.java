package com.jbk.Array;

public class Demo {
	void disp() {
		int a[]= {10,20,30,40,50};
		System.out.println(a[0]);
		System.out.println(a[1]); 
		System.out.println(a[2]);
		System.out.println(a[3]);
		System.out.println(a[4]);	
	
	
		System.out.println("Using for Loop");
		for(int i=0;i<5;i++) {
			System.out.println(a[i]);
		}	
	}
	
	public static void main(String[] args) {
		Demo d=new Demo();
		d.disp();
		
		
	}

}
