package com.jbk.Array;
import java.util.Arrays;
public class Practice {
	public static void main(String[] args) {
		int arr[]= {2,3,4,5,6,7,8,9,10};//static initialization of array
		System.out.println("Before Sorting");
		for(int i=0;i<arr.length;i++) {
			System.out.println(" "+arr[i]);
		}
		Arrays.sort(arr);
		System.out.println("After sorting");
		for(int i=0;i<arr.length;i++) {
			System.out.println(" "+arr[i]);
		}
		System.out.println(" ");
		System.out.println(Arrays.binarySearch(arr, 7));
		System.out.println(Arrays.binarySearch(arr, 5));
		System.out.println(" ");
		int x[][]= {{3,1,2},{5,6,7},{9,8,7,9},{2,4,3}};
		System.out.println("Before sorting");
		for(int i=0;i<x.length-1;i++) {
			for(int j=0;j<x.length-1;j++) {
				System.out.println(x[i][j]+" ");
			}
			System.out.println(" ");
		}
		for(int i=0;i<x.length-1;i++) {
			Arrays.sort(x[i]);
		}
		System.out.println("After sorting");
		for(int i=0;i<x.length-1;i++) {
			for(int j=0;j<x.length-1;j++) {
				System.out.println(x[i][j]+" ");
			}
			System.out.println(" ");
		}
		int s1[]=new int[6];
		s1[0]=11;
		s1[4]=32;//here index position 5 is remaining ,value is not assign to index 5
		for(int i=0;i<s1.length;i++) {
			System.out.println(s1[i]+" ");
		}
		Arrays.fill(s1,66);//here in output the values at all index positions will be 66
		for(int i=0;i<s1.length;i++) {
			System.out.println(s1[i]+" ");
		}
		}
	}
	


