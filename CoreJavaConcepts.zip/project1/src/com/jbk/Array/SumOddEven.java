package com.jbk.Array;
import java.util.Scanner;
//Find sum of all even numbers and odd numbers separately
public class SumOddEven {
       static Scanner sc=new Scanner(System.in);
       int arr[]=new int[10];
       int sum=0;
       int sum1=0;
       void accept(){
    	   System.out.println("Enter 10 Elements of array");
    	   for (int i=0;i<arr.length;i++) {
    		   arr[i]=sc.nextInt();
    	   }   
    	   }
       void display() {
    	   for (int i=0;i<arr.length;i++) {
    		   if(arr[i]%2==0) {
    			   sum=sum+arr[i];
    		   }else {
    			   sum1=sum1+arr[i];
    		   }
    	   }
    	   System.out.println("Sum of Even No.s="+sum);
    	   System.out.println("Sum of Odd No.s="+sum1);
       }
	public static void main(String[] args) {
		SumOddEven obj=new SumOddEven();
		obj.accept();
        obj.display();


		
		

	}

}
