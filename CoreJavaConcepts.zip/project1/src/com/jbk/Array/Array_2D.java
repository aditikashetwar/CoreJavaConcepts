package com.jbk.Array;
public class Array_2D {
	void array() {
		int a1[][]={ {2,3,4},{4,5,6}};
		int a2[][]= {{3,1,5},{1,2,3}};
		
		int a3[][]=new int[2][3];//here 2-Rows and 3-Columns
		//adding and printing addition of 2 matrices
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
				a3[i][j]=a1[i][j]+a2[i][j];
				System.out.print(a3[i][j]+" ");
			}
			System.out.println();//new line
		}
	}

	public static void main(String[] args) {
		Array_2D obj=new Array_2D();
		obj.array();

	}

}
