package com.jbk.Array;
import java.util.Scanner;
public class Hw {
	int a[]=new int [10];
	int sum=0;
	static Scanner sc=new Scanner(System.in);
	void setData() {
		System.out.println("Enter 10 elements of array");
		for(int i=0;i<10;i++) {
			a[i]=sc.nextInt();
		}
	}
	void avg() {
		for(int i=0;i<10;i++) {
			System.out.println(a[i]);
			sum=sum+a[i];
		}
		System.out.println("Average="+(sum/10));
	}

	public static void main(String[] args) {
		Hw obj=new Hw();
		obj.setData();
        obj.avg();
	}

}
