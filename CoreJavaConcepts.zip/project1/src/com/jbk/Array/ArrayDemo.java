package com.jbk.Array;
import java.util.Scanner;
import java.util.Collections;
public class ArrayDemo {
	static Scanner sc=new Scanner(System.in);
	void accept() {
		String a[]=new String [5];
		System.out.println("Enter 5 Array Elements");
		for(int i=0;i<5;i++) {
			a[i]=sc.next();
		}	
		System.out.println("Enter name to be search");
		String nm=sc.next();
				
	}
	public static void main(String[] args) {
		 ArrayDemo obj=new ArrayDemo ();
		 obj.accept();
		 
		 
	}

}
