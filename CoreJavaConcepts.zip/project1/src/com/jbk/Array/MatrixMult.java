package com.jbk.Array;
import java.util.Scanner;
public class MatrixMult {
	static Scanner sc=new Scanner(System.in);
	int a3[][]=new int[3][2];
	void mult() {
		int a1[][]=new int[3][2];
		System.out.println("Enter the elements of first array");
		for(int i=0;i<3;i++) {
			for(int j=0;j<2;j++) {
				a1[i][j]=sc.nextInt();
			}
		}
		int a2[][]=new int[3][2];
		System.out.println("Enter the elements of second array");
		for(int i=0;i<3;i++) {
			for(int j=0;j<2;j++) {
				a2[i][j]=sc.nextInt();
			}
		}
		for(int i=0;i<3;i++) {
			for(int j=0;j<2;j++) {
				a3[i][j]=a1[i][j]*a2[i][j];
				System.out.print(a3[i][j]+" ");
			}
			System.out.println("");
		}
	}

	public static void main(String[] args) {
		 MatrixMult obj=new  MatrixMult();
		 obj.mult();
	}

}
