package com.jbk.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
 class Arraysort {
	static Scanner sc=new Scanner(System.in);
	double d[]=new double[4];
	void setData() {
		System.out.println("Enter 4 Array element");
		for(int i=0;i<4;i++) {
			d[i]=sc.nextDouble();
		}}
		void sortData() {
			System.out.println("Before sorting");
			for(int i=0;i<4;i++) 
				System.out.println(d[i]);
			
				Arrays.sort(d);
				System.out.println(" After sorting");
				for(int i=0;i<4;i++) 
					System.out.println(d[i]);
				
				
				}

	public static void main(String[] args) {
		Arraysort a=new Arraysort();
		a.setData();
        a.sortData();
	}

}
