package com.jbk.Array;
import java.util.Scanner;
//Accept array of 10 integers and display the count of even no's in that array
public class EvenCount {
	static Scanner sc=new Scanner(System.in);
	int a[]=new int [10];
	int count=0;
	void accept() {
		System.out.println("Enetr 10 Array Elements");
		for(int i=0;i<10;i++) {
			a[i]=sc.nextInt();
		}}
		void even() {
			for(int i=0;i<10;i++) {
				if(a[i]%2==0) {
					count++;
				}
			}
			System.out.println("No. of Even no.s present in Array="+count);
		}
	public static void main(String[] args) {
		EvenCount obj=new EvenCount();
		obj.accept();
        obj.even();
	}

}
