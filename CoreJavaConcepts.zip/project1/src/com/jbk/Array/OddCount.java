package com.jbk.Array;
import java.util.Scanner;
public class OddCount {
	static Scanner sc=new Scanner(System.in);
	int a[]=new int[10];
	int count=0;
	void accept() {
		System.out.println("Enetr 10 Elements of Array");
		for(int i=0;i<10;i++) {
			a[i]=sc.nextInt();
		}
	}
	void disp(){
		for(int i=0;i<10;i++) {
			if(a[i]%2!=0) {
				count++;
			}
		}
		System.out.println("no.of odd elements present ="+count);
		
	}

	public static void main(String[] args) {
		OddCount obj=new OddCount();
		obj.accept();
        obj.disp();

	}

}
