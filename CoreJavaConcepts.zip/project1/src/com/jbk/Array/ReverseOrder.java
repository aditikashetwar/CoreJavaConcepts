package com.jbk.Array;
//Accepting arrays in sorting list(Reverse Order)
import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;
public class ReverseOrder {
	static Scanner sc=new Scanner(System.in);
	//Integer is Wrapper class of int 
	//every datatype has its corresponding wrapper class
	Integer a[]=new Integer[4];
	void setData() {
		System.out.println("Enetr Array Elements");
		for(int i=0;i<4;i++)
		a[i]=sc.nextInt();
	}
	void getData() {
		System.out.println("Before Sorting");
		for(int i=0;i<4;i++)
			System.out.println(a[i]);
		Arrays.sort(a,Collections.reverseOrder());
		System.out.println("After Sorting");
		for(int i=0;i<4;i++)
			System.out.println(a[i]);
	}

	public static void main(String[] args) {
		
		ReverseOrder obj=new ReverseOrder();
		obj.setData();
        obj.getData();
	}

}
