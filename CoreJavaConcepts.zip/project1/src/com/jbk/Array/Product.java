package com.jbk.Array;
//Passing an object as a parameter
public class Product {
	int pid;
	String pnm;
	float price;
	
	public void setPrice(float price) {
		this.price=price;
	}

	public void setPnm(String pnm) {
		this.pnm= pnm;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}
	static void disp(Product p) {
		System.out.println(p.pid);
		System.out.println(p.pnm);
	}
	static void compare(Product p1,Product p2) {
		if( p1.price>p2.price) {
			System.out.println("p1 has greater price");
		}else {
			System.out.println("p2 has greater price");
		}
	}
	public static void main(String[] args) {
		Product p1=new Product();
		p1.setPid(101);
		p1.setPnm("pen");
		p1.setPrice(200);
		Product.disp(p1);//static method is always call with class name
		Product p2=new Product();
		p2.setPid(102);
		p2.setPnm("pencil");
		p2.setPrice(250);
		Product.disp(p2);
		Product.compare(p1, p2);
	}

}
