package com.jbk.Array;
import java.util.Scanner;
public class Student {
	int stuid;
	String nm,course;
	
public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
//accepting data for 5 students from user	
static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		int studid;
		String nm,course;
		Student s[]=new Student[5];
		for(int i=0;i<5;i++) {
			s[i]=new Student();
			//initialize each object/reference
			System.out.println("Enter studid");
			studid=sc.nextInt();
			s[i].setStuid(studid);
			System.out.println("Enter studnm");
			nm=sc.next();
			s[i].setNm(nm);
			System.out.println("Enter course");
			course=sc.next();
			s[i].setCourse(course);
		}
		//displaying the details of 5 students
		for(int i=0;i<5;i++) {
			System.out.println("Studid="+s[i].getStuid());
			System.out.println("nm="+s[i].getNm());
			System.out.println("course="+s[i].getCourse());
			
		}
	}
		}


