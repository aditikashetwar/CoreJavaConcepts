package com.jbk.Array;

public class CopyArray {
	void copy() {
		int arr1[]= {2,3,4,5,6,7};
		int arr2[]=new int[6];
		System.out.println("Array:");
		System.out.print("[");
		for(int i=0;i<arr1.length;i++) {
			System.out.print(" "+arr1[i]);
		}
		System.out.print("]");
		System.out.print("[");
		for(int i=0;i<arr1.length;i++) {
			arr2[i]=arr1[i];
			System.out.print(" "+arr2[i]);
		}
		System.out.print("]");
	}

	public static void main(String[] args) {
		CopyArray obj= new CopyArray();
		obj.copy();

	}

}
