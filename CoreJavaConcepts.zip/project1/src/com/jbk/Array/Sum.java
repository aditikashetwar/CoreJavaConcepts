package com.jbk.Array;
import java.util.Scanner;
public class Sum {
	int a[]=new int[5];
	int sum=0;
	static Scanner sc=new Scanner(System.in);
	void setData() {
		System.out.println("Enter array element");
		for(int i=0;i<5;i++) {
			
			a[i]=sc.nextInt();
		}
	}
	void getData() {
		for(int i=0;i<5;i++) {
			System.out.println(i+"th position="+a[i]);
			sum=sum+a[i];
		}
		System.out.println("Sum="+sum);
		
	}

	public static void main(String[] args) {
		Sum s=new Sum();
		s.setData();
        s.getData();
		
	}

}
