package com.jbk.Revision;
//Program to accept an Array of n integer and display the total no of odd and even count
import java.util.Scanner;
public class Program3 {
	static Scanner sc=new Scanner (System.in);int oddcount;
	int evencount;
	int length;
	int arr[];
	
	void accept() {
		
		System.out.println("Enter length of an Array");
		length=sc.nextInt();
		arr=new int[length];
		System.out.println("Enter "+length+" elements of an array" );
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
			if(arr[i]%2==0) {
				evencount++;
			}
			else {
				oddcount++;
			}
		}
		System.out.println("odd count="+oddcount);
		System.out.println("Even count="+evencount);
		
	}

	public static void main(String[] args) {
		Program3 obj=new Program3();
		obj.accept();

	}

}
