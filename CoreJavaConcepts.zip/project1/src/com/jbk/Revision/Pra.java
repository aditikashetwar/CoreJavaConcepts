package com.jbk.Revision;
//factorial of a no
import java.util.Scanner;
public class Pra {
static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		
		
		
	}

}
