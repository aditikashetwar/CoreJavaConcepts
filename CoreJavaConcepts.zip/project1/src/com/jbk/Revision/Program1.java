package com.jbk.Revision;
import java.util.Scanner;
//Accept 10 array elements and count odd and Even elements of Array
public class Program1 {
	static Scanner sc=new Scanner (System.in);
	int arr[]=new int[10];
	int Odd_count=0;
	int Even_count=0;
	void array() {
	System.out.println("Enter 10 array elements");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<arr.length;i++) {
			if(i%2==0) {
				Even_count++;
			}
			else {
				Odd_count++;
			}
		}

		System.out.println("count of odd elements of Array="+Odd_count);
		System.out.println("count of Even elements of Array="+Even_count);
		
	}

	public static void main(String[] args) {
		Program1 obj=new Program1();
		obj.array();

	}

}
