package com.jbk.Revision;

public class Program4 {

	public static void main(String[] args) {
		

	}

}
