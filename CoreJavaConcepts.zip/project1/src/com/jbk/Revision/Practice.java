package com.jbk.Revision;
import java.util.Scanner;
public class Practice {
	static Scanner sc=new Scanner (System.in);
//is vowel present in the string
	public static void main(String[] args) {
	System.out.println("Enetr no u want to print");
	String s=sc.next();
	s=s.toLowerCase();
	int cnt=0;
	for(int i=0;i<s.length()-1;i++) {
		switch(s.charAt(i)) {
		case'a':
			cnt++;
			break;
		case'e':
			cnt++;
			break;
		case'i':
			cnt++;
			break;
		case'o':
			cnt++;
			break;
		case'u':
		    cnt++;
			break;
		}
	}
 if(cnt==0) {
	 System.out.println("No vowels present in the string");
 }
 else {
	 System.out.println("vowels are present in the string");
	 System.out.println("no.of vowels="+cnt);
 }	
		
	}	
}

