package com.jbk.Revision;
//Accept the integer array of 10 elements and store odd elements in an odd array and even elements in an even array.
//display the odd elements array and even elements array
import java.util.Scanner;
public class Program2 {
	static Scanner sc=new Scanner (System.in);
	int arr[]=new int[10];
	static int even[]=new int[10];
	static int odd[]=new int[10];
	void array() {
		System.out.println("Enter 10 Array Elements");
	for(int i=0;i<arr.length;i++) {
		arr[i]=sc.nextInt();
	}}
	void even() {
		int k=0;
		System.out.print("Even values in array are-");
		for(int i=0;i<arr.length;i++) {
			if(arr[i]%2==0) {
				System.out.print(" "+arr[i]);
				even[k]=arr[i];
				k=k+1;
			}
		}
		System.out.println();
	}
	void odd() {
		int j=0;
		System.out.print("Odd values in array are-");
		for(int i=0;i<arr.length;i++) {
			if(arr[i]%2!=0) {
				System.out.print(" "+arr[i]);
				odd[j]=arr[i];
				j=j+1;
			}
		}
	}

	public static void main(String[] args) {
		Program2 obj=new Program2();
		obj.array();
		obj.even();
		obj.odd();
		
		System.out.println();
		
		System.out.print("Even elements stored in Even[] array");
		for(int element:Program2.even) {
			System.out.print(" "+element);
		}
		System.out.println();
		System.out.print("Odd elements stored in odd[] array");
		for(int element:Program2.odd) {
			System.out.print(" "+element);
		}
	}

}
