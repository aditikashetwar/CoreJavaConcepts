package com.jbk.Revision;

public class StaticInstance {
	int a=10;
	static int b=20;
	void jbk() {
		System.out.println("Hello jbk");
		System.out.println(a);
		System.out.println(b);
	}
	static void kiran() {
		System.out.println("jbk");
		System.out.println(b);
	}

	public static void main(String[] args) {
		StaticInstance obj=new StaticInstance ();
		System.out.println(obj.a);
		System.out.println(obj.b);
	}

}
