package com.jbk.Revision;
import java.util.Scanner;
public class Pract {
	byte n=10;
	byte n1=2;
//Interview question 
	public static void main(String[] args) {
		byte n=10;
		byte n1=2;
		//byte sum=n+n1;
		//it will shows an error because additional operator minimum works with int datatype 
		//it will not work with byte datatype
		
		

	}

}
