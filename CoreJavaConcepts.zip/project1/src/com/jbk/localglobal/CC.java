package com.jbk.localglobal;

public class CC {
	void display3() {
		System.out.println("This is class-3");
	}

}
