package com.jbk.localglobal;

public class Exercise1 {
	int a;
	float b;
	String str;
	
	public void operation1() {
		a=10;
		b=4.56f;
		str="java";
	}
	public void operation2() {
		a=20;
		b=65.76f;
		str="Advance java";
	}
	public void display() {
		System.out.println("The integer value ="+a);
		System.out.println("The float value="+b);
		System.out.println("String=  " +str);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise1 obj=new Exercise1();
	    obj.operation1();
        obj.display();
        obj.operation2();
obj.display();



	}

}
