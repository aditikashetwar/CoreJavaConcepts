package com.jbk.localglobal;

public class AA {
	void display() {
		System.out.println("This is class -1");
	}

}
