package com.jbk.localglobal;

public class AddOperation {
	int add_int(int x,int y) {
		return x+y;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     AddOperation add=new AddOperation();
     int z=add.add_int(10, 2);
     System.out.println(z);
	}

}
