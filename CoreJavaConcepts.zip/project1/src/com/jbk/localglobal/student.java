package com.jbk.localglobal;

public class student
{
	//Global declaration
	//Data members
	int studId;//global variable
	String studNm;
	
	// creating a user defined method
	void setData() {
		studId=202;
		studNm="Aditi";
		
	}
	// Assigning the values
	//"= " called assignment operater
	void getData() {
		System.out.println(studId);
		System.out.println(studNm);
	}
	
//it is the main method also called as Built-in-method.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int no;  //local variable
     student a=new student();
     a.setData();
     a.getData();
//when we have to call the then initialized the object 
     //then using object call that method
     




	}

}
