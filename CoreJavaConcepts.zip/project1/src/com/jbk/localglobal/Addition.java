package com.jbk.localglobal;
//Difference between Global & Local variables
public class Addition {
	
	int no=10,no1=20;//global variables
	
	
	void calc() {
		System.out.println(no+no1);
		System.out.println(no*no1);
		
	}
	void mult() {          //method without return datatype and without passing parameter 
		int no2=11;//as it declared in the method ,so it is called as Local variable
		no=9;      //global variables
		no1=10;
		System.out.println(no*no1);
		
	}
	void substract(int x,int y) {        // Method with passing parameter and without return datatype
		int no4=70;  //Local variable
		
		System.out.println(x - y);
	}
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no3;//local variable     (Declaration)
		no3=90;    //Initialization of variable
		Addition s=new Addition();    
		s.calc();//call the method
		s.mult();
		s.substract(7,5);
	}

}
