package com.jbk.localglobal;

public class dataType_char {
	void join() {
		char a='J';
		char b='A';
		char c='V';
		char d='A';
		System.out.println("The joined Letters are : "+a+b+c+d);
		
		
		
	}

	public static void main(String[] args) {
		dataType_char v=new dataType_char();
		v.join();
		

	}

}
