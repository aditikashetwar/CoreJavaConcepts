package com.jbk.localglobal;

public class mainExercise2 {

	public static void main(String[] args) {
		AA obj1=new AA();
		obj1.display();
        BB obj2=new BB();
        obj2.display2();
        CC obj3=new CC();
        obj3.display3();

		// TODO Auto-generated method stub

	}

}
