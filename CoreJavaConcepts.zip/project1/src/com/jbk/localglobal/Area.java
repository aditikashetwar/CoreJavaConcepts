package com.jbk.localglobal;

public class Area {
	double square(double n) {
		 double s=n*n;
		return s;
	}
public static void main(String[] args) {
	Area sq=new Area();
	double a=sq.square(4);
	System.out.println(a);
	
}
}
