package com.jbk.localglobal;
//class without main method
public class Stringconcat {
	String s1,s2;
	
	void concat(String s1,String s2) {
		this.s1=s1;
		this.s2=s2;
		System.out.println(this.s1+this.s2);
		
	}

	

}
