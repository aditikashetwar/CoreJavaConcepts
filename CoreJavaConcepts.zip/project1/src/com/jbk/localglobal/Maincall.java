package com.jbk.localglobal;
// calling methods of different classes
public class Maincall {

	public static void main(String[] args) {
		Stringconcat s=new Stringconcat();
		s.concat("Hello","pune");
		
		methodpassing p= new methodpassing();
		p.product(5, 8);
		
		Rect_area r=new Rect_area();
		int k=r.Area();
		System.out.println(k);
		

	}

}
