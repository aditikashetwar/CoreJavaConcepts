package com.jbk.localglobal;

public class BB {
	void display2() {
		System.out.println("This is class-2");
	}

}
