package com.jbk.localglobal;

public class Rectanglearea {
     int length,breadth;
     void rectangle(int l,int b) {
    	 length=l;
    	 breadth =b;
     }
     public int area() {
    	 return length*breadth;
     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectanglearea r=new Rectanglearea ();
		r.rectangle(3,4);
		System.out.println(r.area());
		

	}

}
