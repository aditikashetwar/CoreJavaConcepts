package com.jbk.localglobal;

public class dataType_int {
	int a=15000;
	int b=-20000;
	void add() {
		int c=a+b;
		System.out.println("The value of c is: "+c);
	}

	public static void main(String[] args) {
		dataType_int m=new dataType_int();
		m.add();

	}

}
