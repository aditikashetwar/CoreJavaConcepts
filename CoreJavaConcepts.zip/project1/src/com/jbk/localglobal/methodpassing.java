package com.jbk.localglobal;

public class methodpassing {
	
	int no,no1;
	void product(int no,int no1) {
		System.out.println(no*no1);
		
	}
	
	void add(int no,int no1) {
		this.no=no;//this.no is Global variable
		this.no1=no1;//no is local variable
		System.out.println(this.no+this.no1);
		
	}
	void disp() {
		System.out.println(this.no);
	}

	public static void main(String[] args) {
		methodpassing p=new methodpassing();
		p.product(3, 5);
		p.add(5, 8);
		p.disp();
		// TODO Auto-generated method stub

	}

}
