package com.jbk.localglobal;

public class book {
	int bookId;
	float bookPrice;
	String bookName;
	
	void setData() {
		bookId=305;
		bookPrice=300.65f;
		bookName="Rich Dad Poor Dad";
	}
	void getData() {
		System.out.println("Book Id= "+bookId);
		System.out.println("Book Price= "+bookPrice);
		System.out.println("Book Name= "+bookName);
	}
	public static void main(String[] args) {
		book s=new book();
		s.setData();
		s.getData();
		
	}

}
