package com.jbk.localglobal;

public class Rect_area {
	int l,b;
	 int Area() {
		l=10;
		b=20;
		int a=l*b;
		return a;
		
	}

}
