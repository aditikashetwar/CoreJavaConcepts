package com.jbk.localglobal;

public class Method_Ex1_Test {

	public static void main(String[] args) {
		Method_Ex1 obj=new Method_Ex1();
		obj.add();
obj.sub();
obj.mult();
obj.div();
		// TODO Auto-generated method stub

	}

}
