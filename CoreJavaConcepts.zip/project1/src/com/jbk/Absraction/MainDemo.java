package com.jbk.Absraction;

public class MainDemo {

	public static void main(String[] args) {
		//we cannot initialize the abstract class
		Rectangle s=new Rectangle();
		s.dispnm();
		s.shape_rect();
        s.area();


        Circle c=new Circle();
        c.Shape_cir();
        c.area();

	}

}
