package com.jbk.Absraction;

public class Customer implements Iproduct,Purchase {
	void msg() {
		System.out.println("Welcome");
	}
	public void disp(String prodnm) {
		System.out.println("Product Name="+prodnm);
	}
	public void bill(String pnm,int qty) {
		if(pnm.equals("Book")) {
			System.out.println("bill="+qty*prate1);
		}
		else {
			System.out.println("bill="+qty*prate2);
		}
	}

	public static void main(String[] args) {
	Customer c=new Customer();
	c.msg();
c.disp("Pen");
c.bill("pen", 4);
	

	}

}
