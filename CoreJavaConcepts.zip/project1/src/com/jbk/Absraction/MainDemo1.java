package com.jbk.Absraction;

public class MainDemo1 {

	public static void main(String[] args) {
//here we have created the object of abstract class and initialize the derived class        
		//so we can only give call to the methods of abstract class
		Shape s=new Rectangle();
		s.dispnm();
        s.area();
        
        Shape c=new Circle();
        c.dispnm();
        c.area();

	}
	

}
