package com.jbk.Absraction;

public interface Iproduct {
	int prate1=900;
	int prate2=300;
	void disp(String prodnm);

}
