package com.jbk.Absraction;
import java.util.HashSet;
public class CountOfDuplicate {
 //Find Duplicate words from String and count how many times it get duplicate
	public static void main(String[] args) {
		
		String str="java by kiran institute institute";
		int count=0;
		String a[]=str.split(" ");

		HashSet<String>all=new HashSet<String>();

		for(String l:a ){
		     if(all.add(l)==false){
		       System.out.println(l);
		      count++;
		}
		    }
		System.out.println(count);
	}

}
