package com.jbk.Absraction;

public interface Ishape {
    int no=100;
    void area(int l,int b);
}
