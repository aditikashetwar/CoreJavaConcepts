package com.jbk.Absraction;

public class Circle extends Shape{
          void Shape_cir() {
        	  System.out.println("Circle");
          }
          void area() {
        	  double radius=3.4;
        	  System.out.println("Area of circle="+Math.PI*radius*radius);
          }
}
