package com.jbk.Absraction;

public interface Purchase {
	void bill(String pnm,int qty);

}
