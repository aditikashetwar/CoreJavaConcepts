package com.jbk.Absraction;
//class implementing an interface
public class Rectangle1 implements Ishape {
	//Defining method of interface
	public void area(int l, int b) {
	System.out.println("Area="+(l*b));
	}
	void disp() {
		System.out.println(no);
	}

	public static void main(String[] args) {
		Rectangle1 obj=new Rectangle1();
		obj.area(4, 5);;
obj.disp();
	}

}
