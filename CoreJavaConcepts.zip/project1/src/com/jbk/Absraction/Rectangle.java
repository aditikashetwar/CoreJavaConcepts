package com.jbk.Absraction;
//here we have used the Hirarchical inheritance ,as we have extends two classes from one class 
//Shape-Base class & Rectangle & Circle are derived from it
public class Rectangle extends Shape{
	void shape_rect() {
		System.out.println("Rectangle");
	}
		void area() {
		int l=12;
		int b=2;
			System.out.println("Area of rectangle="+(l*b));
		}

	}

	
