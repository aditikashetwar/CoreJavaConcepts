package com.jbk.Absraction;
//Abstract class
public abstract class Shape {
	// Abstract method
	//we cannot define the abstract method in abstract class
     abstract void area();
     //Non Abstract method
     void dispnm() {
    	 System.out.println("Shape Class");
     }
     
     
}
