package com.jbk.placementprogram;
import java.util.Scanner;
public class Reverse_No {
	public static void main(String[] args) {
		
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter no. u want to reverse");
	int n=sc.nextInt();
	int digit;
	
	while(n>0) {
		digit=n%10;
		System.out.print(digit);
		n=n/10;
	}

	}

}
