package com.jbk.placementprogram;
import java.util.HashSet;
public class DuplicateElementInString {

	public static void main(String[] args) {
		String a[]= {"java","java","Angular","python","python","sql"};
		
		HashSet<String>all=new HashSet<String>();
		
		for(String l:a) {
			if(all.add(l)==false) {
				System.out.println(l);
			}
		}

	}

}
