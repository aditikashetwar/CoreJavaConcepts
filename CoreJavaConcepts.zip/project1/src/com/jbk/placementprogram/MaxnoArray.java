package com.jbk.placementprogram;
//Max No. in Array
public class MaxnoArray {
	int a[]= {90,1000,67,98,65};
	int temp;
	void print() {
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		System.out.println("Maximum No="+a[a.length-1]);	
	}

	public static void main(String[] args) {
		MaxnoArray obj=new MaxnoArray();
		obj.print();

	}

}
