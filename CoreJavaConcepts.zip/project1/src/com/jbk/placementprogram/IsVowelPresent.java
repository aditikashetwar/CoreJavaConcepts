package com.jbk.placementprogram;

public class IsVowelPresent {

	public static void main(String[] args) {
		String s="aditi Kashetwar";
		s=s.toLowerCase();
		int count=0;
		for(int i=0;i<=s.length()-1;i++) {
			switch(s.charAt(i)) {
			case 'a':
				count ++;
				break;
			case 'e':
				count++;
				break;
			case 'i':
				count++;
				break;
			case 'o':
				count++;
				break;
			case 'u':
				count++;
				break;
			}	
		}System.out.println("No.of vowels= "+count);
		if(count==0) {
			
			System.out.println("No vowels present in the String");
		}else {
			System.out.println("Vowels are present in the String ");
		}
		}
		

	}


