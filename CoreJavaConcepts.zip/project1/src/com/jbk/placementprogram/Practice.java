package com.jbk.placementprogram;
//Armstrong number
import java.util.Scanner;
import java.util.HashSet;
public class Practice {
//insertion of two arrays 
	public static void main(String[] args) {
		
		
		String s="mam";
		String reverse="";
		for(int i=s.length()-1;i>=0;i--) {
			reverse= reverse +s.charAt(i);
		}
		if(s.equals(reverse)) {
			System.out.println("palindrome");
		}
		else {
			System.out.println("not");
		   }
			
		}
		
	}
		

	
	