package com.jbk.placementprogram;
//Displaying Array Elements in Descending Order
import java.util.Scanner;
public class DescendingArray {
	static Scanner sc=new Scanner(System.in);
	void disp() {
		int a[]= {9,5,3,8,6,2,1,4};
		int temp;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]<a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
		
		}
	

	public static void main(String[] args) {
		DescendingArray obj=new DescendingArray();
		obj.disp();

	}

}
