package com.jbk.placementprogram;

public class MiniNo {
	int a[]= {60,67,90,54,100,10};
	int temp;
	void mini() {
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		System.out.println("Maximum No="+a[0]);
	}
	
	

	public static void main(String[] args) {
		MiniNo obj=new MiniNo();
		obj.mini();
	}

}
