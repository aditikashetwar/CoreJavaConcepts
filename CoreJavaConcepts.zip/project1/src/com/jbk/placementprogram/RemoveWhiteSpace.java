package com.jbk.placementprogram;

public class RemoveWhiteSpace {

	public static void main(String[] args) {
		String s="T  he   Ki r a n   Ac  ad e m y ";
		System.out.println("Before - "+s);
		s=s.replaceAll(" ", "");
		System.out.println("After - "+s);		

	}

}
