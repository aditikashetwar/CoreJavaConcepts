
package com.jbk.placementprogram;
//Reverse a word in String
public class ReverseStringWord {

	public static void main(String[] args) {
		String str="The kiran Academy pune";
		
		String a[]=str.split(" ");//it will split the string array at the spaces
		for(int i=a.length-1;i>=0;i--) {
			System.out.print(a[i]+" ");
		}
	}
}
