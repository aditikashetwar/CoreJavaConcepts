package com.jbk.placementprogram;
import java.util.Scanner;
public class Sum_Of_Digit {
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter no");
		int n= sc.nextInt();
		int digit;
		int sum=0;
		while(n>0) {//It will check the condition
			digit=n%10;//it will gives remainders
			sum=sum+digit;//It will add digits
			n=n/10;//It will divide no
		}//loop terminated
		System.out.println("Sum of digits="+sum);

	}

}
