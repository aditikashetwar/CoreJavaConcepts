package com.jbk.placementprogram;
import java.util.Scanner;
//Program to swap the no.s without third variable
public class Swapping_without_3rd_variable {
	static Scanner sc=new Scanner(System.in);
	void swap() {
		System.out.println("Enter 1st no to swap");
		int a=sc.nextInt();
		System.out.println("Enter 2nd no to swap");
		int b=sc.nextInt();
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("a="+a);
		System.out.println("b="+b);
	}

	public static void main(String[] args) {
		Swapping_without_3rd_variable obj=new Swapping_without_3rd_variable ();
		obj.swap();
	}

}
//a=a+b;
//b=a-b;
//a=a-b;

//these addition , substraction operations are used to swapping of variable without using third variable.