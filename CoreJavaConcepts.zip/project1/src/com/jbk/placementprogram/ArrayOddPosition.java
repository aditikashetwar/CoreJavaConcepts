package com.jbk.placementprogram;

public class ArrayOddPosition {

	public static void main(String[] args) {
		int a[]= {1,3,6,8,9,10,5,7,9};
		for(int i=1;i<a.length;i+=2) //i+=2 means i=i+2
		{
			System.out.println(a[i]);
		}
	}

}
