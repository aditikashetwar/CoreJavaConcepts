package com.jbk.placementprogram;
import java.util.Scanner;
public class Armstrong_No {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no");
	    int n=sc.nextInt();
	   //System.out.println("Enter same no. as u entered first");
	   // int original_no=sc.nextInt();
		int digit;
		int cube=0;
		int temp=n;
		while(n>0) {
			digit=n%10;
			cube=cube+(digit*digit*digit);
			n=n/10;
		}
		if(temp==cube) {
			System.out.println("It is a Armstrong Number");
		}
		else {
			System.out.println("It is not a Armstrong Number");
		}

	}

}
