package com.jbk.placementprogram;
import java.util.Scanner;
public class Fibonacci_series {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no");
		int n=sc.nextInt();
		int no=0;
		int no1=1;
		System.out.print(no+" "+no1);
		int sum=0;
		for(int i=3;i<=n;i++) {
			sum=no+no1;
			System.out.print(" "+sum);
			no=no1;
			no1=sum;
		
			
		}
		
	}

}
