package com.jbk.placementprogram;
import java.util.Scanner;
public class PalindromeNo {
	static Scanner sc=new Scanner(System.in);
	void check() {
		int digit;
		int sum=0;
		System.out.println("Enter no.");
		int n=sc.nextInt();
		int temp=n;
		
		while(n>0) {
			digit=n%10;
			sum=(sum*10)+digit;
			n=n/10;	
		}if(temp==sum) {
			System.out.println("No.is Palindrome");
		}else {
			System.out.println("No.is not Palindrome");
		}
	}
	public static void main(String[] args) {
		PalindromeNo obj=new PalindromeNo();
		obj.check();
		

	}

}
