package com.jbk.placementprogram;
//Displaying Array Elements in Ascending Order
public class SortingArray {
	int a[]= {45,76,89,90,54,34};
	int temp;
	int i=0;
	void sort() {
		
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]>a[j]) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
		
	}
	

	public static void main(String[] args) {
		SortingArray obj=new SortingArray();
		obj.sort();

	}

}
