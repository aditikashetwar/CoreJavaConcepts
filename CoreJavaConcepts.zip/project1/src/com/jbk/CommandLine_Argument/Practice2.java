package com.jbk.CommandLine_Argument;

public class Practice2 {

	public static void main(String[] args) {
		int n=Integer.parseInt(args[0]);
		if(n%2==0) {
			System.out.println("Even number");
		}
		else {
			System.out.println("Odd number");
		}

	}

}
