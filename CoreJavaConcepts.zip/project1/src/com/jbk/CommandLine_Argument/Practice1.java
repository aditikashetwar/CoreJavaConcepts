package com.jbk.CommandLine_Argument;
//Program to find max number
public class Practice1 {
	public static void main(String[] args) {
		int x[]= {3,4,5,6,7};
		int a=Integer.parseInt(args[0]);//Every primitive datatype has its corresponding Wrapper class.
		int b=Integer.parseInt(args[1]);
		int c=Integer.parseInt(args[2]);
		
		if((a>b)&&(a>c)) {
			System.out.println("max="+a);
		}
		else if(b>c){
			System.out.println("max="+b);
		}else {
			System.out.println("max="+c);
		}

	}

}
//how to pass arguments --->
//1.go to Run 
//2.go to Run configuration
//3.go to Arguments
//4.pass the many arguments simply by spacing
//Run