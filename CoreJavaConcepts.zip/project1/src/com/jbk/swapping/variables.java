package com.jbk.swapping;
//Swapping of variable with 3rd variable
public class variables {

	public static void main(String[] args) {
	int no=10,no1=20;
	int t=0;
	t=no1;
	no1=no;
	no=t;
	
System.out.println("no="+no+","+"no1="+no1);

//Swapping of variable without 3rd variable
no=no+no1;
no1=no-no1;
no=no-no1;
System.out.println("no="+no);
System.out.println("no1="+no1);
	}

}
