package com.jbk.FileHandling;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
//Serialized the object -storing it in a file
public class FileSerialize {
	public static void main(String[] args) {
		try {
			Student s1=new Student(101,"Aditi");
			Student s2=new Student(102,"Mayuri");
			//Creating stream and writing the object
			FileOutputStream fout=new FileOutputStream("f.txt");
			ObjectOutputStream	out =new ObjectOutputStream(fout);	
			//writing the object s1 into the file f.txt
			out.writeObject(s1);
			out.writeObject(s2);
			out.flush();
            //closing the stream
             out.close();
           System.out.println("Success");
		}
		catch(Exception e ) {
			System.out.println(e);
		}

	}

}
