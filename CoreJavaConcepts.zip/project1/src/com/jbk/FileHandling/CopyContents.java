package com.jbk.FileHandling;
import java.io.*;
import java.io.IOException;
public class CopyContents {

	public static void main(String[] args) {
		try {
			FileReader fr=new FileReader("fileeg1.txt");
			FileWriter fw=new FileWriter("fileEx2.txt");
			int i=0;
			while((i=fr.read())!=-1) {
				fw.write(i);
				System.out.print((char)i);
			}
			fr.close();
            fw.close();//for copy the content of the file it is mandatory to close both files
		}catch(IOException e) {
			e.printStackTrace();
		}

	}

}
