package com.jbk.FileHandling;
import java.io.File;//File is a class of io package
public class FileProperty {

	public static void main(String[] args) {
		File obj=new File("fileeg1.txt");
		//It will display true if the file exists
		System.out.println(obj.exists());
		//It will display true if u hv to permission to read the contents of the file
		System.out.println(obj.canRead());
		//It will display name along with the extension of the file
		System.out.println(obj.canWrite());
		//it will display the path where the file is stored
		System.out.println(obj.getName());
		//check if the file is directory of file
		System.out.println(obj.getAbsolutePath());
		//size of the file
		System.out.println(obj.isFile());
		System.out.println(obj.length());

	}

}
