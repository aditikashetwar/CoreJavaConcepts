package com.jbk.FileHandling;
import java.io.FileWriter;
import java.io.IOException;
public class Writerfile1 {

	public static void main(String[] args)throws IOException {
		FileWriter fwrite=new FileWriter ("fileEx2");
		fwrite.write("Aditi is learning how to creat a file");
		fwrite.close();
		System.out.println("content is successfully wrote into the file");
		

	}

}
