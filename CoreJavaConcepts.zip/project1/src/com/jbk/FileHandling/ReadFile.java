package com.jbk.FileHandling;
import java.io.FileReader;
import java.io.*;
public class ReadFile {

	public static void main(String[] args) {
		try {
			FileReader fr=new FileReader("fileeg1.txt");
			int i=0;
			while((i=fr.read())!=-1) {
				System.out.print((char)i);//If u not written char here then it gives ASCii
				                             //values
			}}
			catch(FileNotFoundException e) {
				System.out.println("File does not found");
			}
		catch(IOException e) {
			System.out.println(e);
		}
		}

	}


