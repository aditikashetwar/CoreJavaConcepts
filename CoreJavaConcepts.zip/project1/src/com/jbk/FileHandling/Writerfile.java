package com.jbk.FileHandling;
import java.io.FileWriter;
import java.io.IOException;
//writing to a file
public class Writerfile {
	public static void main(String[] args) {
		try {
			//creating a file fileeg1.txt;
		FileWriter fwrite= new FileWriter("fileeg1.txt");
		//writing into the file
		fwrite.write("Aditi is studying in JBK Tutorials");
		//fwrite- object,write-method,we are calling method by using object
		//closing the stream
		fwrite.close();
		System.out.println("Content is successfully write into the file");	
	}
		catch(IOException e){
			System.out.println("unexpected error occured");
		}

	}

}
