package com.jbk.FileHandling;
import java.io.Serializable;
public class Student implements Serializable{
	int id;
	String Name;
	public Student(int id,String Name) {
		this.id=id;
		this.Name=Name;
	}

}
