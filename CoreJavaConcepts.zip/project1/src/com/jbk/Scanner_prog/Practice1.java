package com.jbk.Scanner_prog;

public class Practice1 {
	public int sm(int n,int n1,int n2) {
		return n+n1+n2;
	}

}
