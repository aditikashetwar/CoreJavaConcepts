package com.jbk.Scanner_prog;
//sum of two numbers;
import java.util.Scanner;
public class Exercise1 {

	public static void main(String[] args) {
		
		int num1,num2,sum;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter num1");
		num1 =sc.nextInt();
		System.out.println("Enter num2");
		num2=sc.nextInt();
		sc.close();
        sum=num1+num2;
        System.out.println("The of these nos is: "+sum);
		

	}

}
