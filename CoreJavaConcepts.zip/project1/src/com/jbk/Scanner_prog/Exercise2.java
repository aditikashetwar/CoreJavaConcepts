package com.jbk.Scanner_prog;

import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter num1");
		int no1=sc.nextInt();
		System.out.println("Enter no2");
		int no2=sc.nextInt();
		System.out.println("The substraction is: "+(no1-no2));
		
		

	}

}
