package com.jbk.Scanner_prog;

public class Exercise5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no=10;
		System.out.println(no);
		no=no+3;
		System.out.println(no);
		no=no-10;
		System.out.println(no);
		no=no*10;
		System.out.println(no);
		no=no/10;
		System.out.println(no);

	}

}
