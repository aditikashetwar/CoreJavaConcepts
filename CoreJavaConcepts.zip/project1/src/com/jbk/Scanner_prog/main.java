package com.jbk.Scanner_prog;

public class main {

	public static void main(String[] args) {
		

		Practice1 oj=new Practice1();
		int sum=oj.sm(8, 10, 20);
		System.out.println("The of these 3 nos. is: "+sum);
		
		Practice2 obj=new Practice2();
		double mult = obj.product(23.98, 43.87);
		System.out.println("The product of these nos. is: "+mult);
		
		Program3 ob=new Program3();
		ob.concat("Aditi ", "Kashetwar");
	}

}
