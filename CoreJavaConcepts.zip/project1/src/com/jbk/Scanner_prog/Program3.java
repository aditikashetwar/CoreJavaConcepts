package com.jbk.Scanner_prog;

public class Program3 {
	void concat(String s,String s1) {
		System.out.println(s+s1);
		
	}
	

}
