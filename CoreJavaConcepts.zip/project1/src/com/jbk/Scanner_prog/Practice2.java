package com.jbk.Scanner_prog;

public class Practice2 {
	double d,d1;
	double product(double d,double d1) {
		this.d=d;
		this.d1=d1;
		return d*d1;
	}

}
