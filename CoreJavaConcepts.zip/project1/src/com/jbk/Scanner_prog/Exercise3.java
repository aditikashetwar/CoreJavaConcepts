package com.jbk.Scanner_prog;

import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter n1");
		float n1=sc.nextFloat();
		System.out.println("Enter n2");
		float n2=sc.nextFloat();
		System.out.println("The multiplication of these nos is: "+(n1*n2));

	}

}
