package com.jbk.Scanner_prog;
import java.util.Scanner;
public class Guess_no {

	public static void main(String[] args) {
		int secretno,guess;
		Scanner sc=new Scanner(System.in);		
		System.out.println("Enter chances for guessing");
		int n=sc.nextInt();
		System.out.println("Enter secrete number");secretno=sc.nextInt();
		
		for(int i=1;i<=n;i++) {
			System.out.println("Enter your Guess");
		    guess=sc.nextInt();	
			 
		   if(secretno<guess) {
			   System.out.println("Enter Lower no");
		   }
		   else if(secretno>guess) {
			   System.out.println("Enter Higher no");
		   }
		   else if(secretno==guess){
			   System.out.println("You win");
		   }
		  
		   }
		   }
		
	}


