package com.jbk.Static;

public class problem1 {
	static int count=0;
	static void increment() {
		count++;
	}
	public static void main(String[] args) {
		problem1 obj1=new problem1();
		obj1.increment();
		problem1 obj2=new problem1();
		obj2.increment();
		System.out.println("Obj 1:count is:"+obj1.count);
		System.out.println("obj 2:count is:"+obj2.count);
		
				
		

	}

}
