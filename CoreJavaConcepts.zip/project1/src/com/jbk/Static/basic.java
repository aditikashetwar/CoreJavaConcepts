package com.jbk.Static;

public class basic {
	int no;
	static int no1;
	void m1() {
		no=10;//In non static method we can access both static and non static variables
		no1=20;
		System.out.println(no);
		System.out.println(no1);
	}
	static void m2() {
		no1=30;//static variables can access only in static method
		System.out.println(no1);
	}
	public static void main(String[] args) {
		basic c=new basic();
		c.m1();
        c.m2();
	}
}
