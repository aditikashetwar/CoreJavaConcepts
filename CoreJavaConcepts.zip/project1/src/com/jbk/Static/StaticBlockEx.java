package com.jbk.Static;

public class StaticBlockEx {
	static int a;
	static int b;
	static {
		System.out.println("Static Block");
		a=10;
		b=20;
	}

	public static void main(String[] args) {
		System.out.println("Main method started");
		System.out.println("Value of a="+a);
		System.out.println("value of b="+b);
//Here we dont have to creat object as static method will access without 
		//intialization of object
	}

}
