package com.jbk.finalvariable;

public class Finaldemo {
	final int no=100;
	void practice() {
		final int no=1000;
		System.out.println(no);//it will print the value of local variable as no=1000
		System.out.println(this.no);//it will print the value of global variable no=100
	}

	public static void main(String[] args) {
		Finaldemo d=new Finaldemo();
		d.practice();
	

	}

}
