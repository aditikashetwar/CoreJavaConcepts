package com.jbk.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet; //it will take only in case of select
import java.sql.SQLException;
import java.sql.Statement;
public class SelectDemo {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch424","root","root");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from student");
			while(rs.next()) {
				int id=rs.getInt(1);
				String nm=rs.getString(2);
				int courseid=rs.getInt(3);
				String city=rs.getString(4);
				
				System.out.println("Id is: "+id);
				System.out.println("Name is: "+nm);
				System.out.println("courseid is: "+courseid);
				System.out.println("city is: "+city);
				
			}
		}
		catch(ClassNotFoundException e) {
			System.out.println("Driver class error");
		}
		catch(SQLException e) {
			System.out.println("Driver class error");
		}
	}

}
