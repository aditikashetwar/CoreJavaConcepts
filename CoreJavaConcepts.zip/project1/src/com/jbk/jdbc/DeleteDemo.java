package com.jbk.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
//delete a record from student table;
public class DeleteDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch424","root","root");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("delete from student where studid=2");
			System.out.println("Record deleted");
		}
		catch(ClassNotFoundException e) {
			System.out.println("Error");
		}
		catch(SQLException e) {
			System.out.println("Driver class error");
		}

	}

}
