package com.jbk.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
public class UpdateDemo {

	public static void main(String[] args)throws Exception {
		
	Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch424","root","root");
	PreparedStatement pmt=con.prepareStatement("update student set studcity='mumbai' where studid=4");
	pmt.executeUpdate();
	System.out.println("record updated");      

}
}