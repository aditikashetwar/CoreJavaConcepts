package com.jbk.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
//insert records in the student table
public class InsertDemo {
	public static void main(String[]args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch424","root","root");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("Enter into student values(7,'advika',102,'Mumbai')");
			System.out.println("Record inserted");
		}
		catch(ClassNotFoundException e) {
			System.out.println("Driver class Error");
		}
			catch(SQLException e) {
				System.out.println("Driver class error");
			}

	

	}}

