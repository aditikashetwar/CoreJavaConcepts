package com.jbk.loops;

public class square_no {

	public static void main(String[] args) {
		System.out.print("Square of nos- ");
		for(int i=1;i<=10;i++) {
			int square=i*i;
			System.out.print(" "+square);
		}

	}

}
