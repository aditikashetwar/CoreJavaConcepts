package com.jbk.loops;
//program to print even nos.between N-----N1
import java.util.Scanner;

public class use_Scanner {
	void even() {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter no N");
		int n=sc.nextInt();
		System.out.println("Enter no N1");
		int n1=sc.nextInt();
		for( int i=n;i<=n1;i++) {
			if(i%2==0) {
			System.out.println(i);
		}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		use_Scanner obj=new use_Scanner();
		obj.even();

	}

}
