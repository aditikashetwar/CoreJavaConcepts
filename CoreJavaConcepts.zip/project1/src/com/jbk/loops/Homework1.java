package com.jbk.loops;
//write a program to print nos.from 1500 to 1000 in descending order
public class Homework1 {

	public static void main(String[] args) {
		for(int i=1500;i>=1000;i--) {
			System.out.println(i);
		}


	}

}
