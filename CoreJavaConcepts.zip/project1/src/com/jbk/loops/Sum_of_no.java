package com.jbk.loops;
import java.util.Scanner;
public class Sum_of_no {
//Add 5 nos.
	void sum() {
		
		int s=0;
		for(int i=1;i<=5;i++) {
			Scanner sc=new Scanner (System.in);
			System.out.println("Enter nos. what u want to add ");
			int n=sc.nextInt();
			
			s=s+i;
		}
				System.out.println("Sum= "+s);
		
		
	}
	public static void main(String[] args) {
		Sum_of_no obj=new Sum_of_no();
		obj.sum();
		

	}

}
