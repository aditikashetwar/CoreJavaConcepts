package com.jbk.loops;
import java.util.Scanner;
public class substract {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many nos. u want to substract");
		int count=sc.nextInt();
		System.out.println("Enter the no from which u have to substract the nos.");
		int sub=sc.nextInt();
		for(int i=1;i<=count;i++) {
			
		System.out.println("Enter nos");
		int no=sc.nextInt();
			sub=sub-no;
		}
	System.out.println("subsraction= "+sub);

	}

}
