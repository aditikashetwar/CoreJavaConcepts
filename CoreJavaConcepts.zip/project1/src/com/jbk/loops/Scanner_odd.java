package com.jbk.loops;
import java.util.Scanner;
//Program to print odd no between N----N1
public class Scanner_odd {
	void odd() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no N");
		int n=sc.nextInt();
		System.out.println("Enter no N1");
		int n1=sc.nextInt();
		for(int i=n;i<=n1;i++) {
			if(i%2!=0) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		Scanner_odd obj=new Scanner_odd();
		obj.odd();

	}

}
