package com.jbk.loops;
import java.util.Scanner;
public class Homework2 {
//write a program to print"Welcome in JBK" n times accept the input from user
	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of n");
		n=sc.nextInt();
		for(int i=1;i<=n;i++) {
			System.out.println("Welcome to JBK");
		}
		

	}

}
