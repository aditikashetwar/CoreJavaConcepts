package com.jbk.loops;
//write a program to print odd nos between 200 to 250
public class Homework3 {
	public static void main(String[] args) {
		System.out.println("The odd nos.From 200 to 250 are");
		for(int i=200;i<=250;i++) {
			if(i%2!=0) {
				
				System.out.println(i);
			}
		}

	}

}
