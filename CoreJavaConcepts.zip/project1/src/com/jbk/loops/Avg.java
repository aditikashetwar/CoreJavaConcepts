package com.jbk.loops;

import java.util.Scanner;

public class Avg {
	void avg() {
		int s=0;
		for(int i=1;i<=5;i++) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter ur nos.");
			int n=sc.nextInt();
			s=s+i;
		}
		System.out.println("Avg= "+(s/5));
	}

	public static void main(String[] args) {
		Avg obj=new Avg();
		obj.avg();

	}

}
