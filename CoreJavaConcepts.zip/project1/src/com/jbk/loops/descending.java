package com.jbk.loops;
public class descending {
	public static void main(String[] args) {
		
	for(int i=50;i>=1;i--) {
		System.out.println(i);}
	}

}
