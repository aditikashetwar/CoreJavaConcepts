package com.jbk.loops;



public class evenNo {
	
	void odd() {
		//program to print odd no between 1 to 100
				for(int i=1;i<=100;i+=2) {
					System.out.println(i);
				}
	}
//program to print even no between 2 to 100 
	public static void main(String[] args) {
		for(int i=2;i<=100;i+=2) {
			System.out.println(i);
			
		}
		System.out.println("");
		evenNo obj=new evenNo();
		obj.odd();
		
	

	}

}
