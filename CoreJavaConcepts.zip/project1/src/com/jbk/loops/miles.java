package com.jbk.loops;

import java.util.Scanner;
//WAP to convert a distance from km to miles
public class miles {

	public static void main(String[] args) {
		double miles,km;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter distance in km");
		km=sc.nextDouble();
		
		miles=0.062*km;
		System.out.println(miles+" miles");
		
		//conversion of km to m
		double m;
		System.out.println("Enter distance in km");
		km=sc.nextDouble();
		m=1000*km;
		System.out.println("m="+m);
		

	}

}
