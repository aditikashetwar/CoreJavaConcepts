package com.jbk.loops;

public class Fibonacci {
	public static void main(String[] args) {
		
		System.out.print("Fabonacci series - ");
		int n1=0,n2=1,sum,count=15;
		System.out.print(n1+" "+n2);
		for(int i=3;i<count;i++) {
			sum=n1+n2;
			System.out.print(" "+sum);
			n1=n2;//The value of n2 is stored in n1;
			n2=sum;//The value of sum is stored in n2;
			
		}

	}

}
