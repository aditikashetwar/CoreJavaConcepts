package com.jbk.loops;

import java.util.Scanner;

public class Prod_nos {
	void mult() {
		
		int p=1;
		for(int i=1;i<=3;i++) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter nos. u want to multiply");
			int no=sc.nextInt();
			p=p*no;
		}
		System.out.println("Prod= "+p);
	}

	public static void main(String[] args) {
		Prod_nos obj=new Prod_nos();
		obj.mult();
	}

}
