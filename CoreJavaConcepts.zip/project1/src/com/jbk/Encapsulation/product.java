package com.jbk.Encapsulation;
import java.util.Scanner;
//data variables are declared private and access in same package & same class 
public class product {
	private int proid;
	private float prodcost;
	private String prodnm;
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public float getProdcost() {
		return prodcost;
	}
	public void setProdcost(float prodcost) {
		this.prodcost = prodcost;
	}
	public String getProdnm() {
		return prodnm;
	}
	public void setProdnm(String prodnm) {
		this.prodnm = prodnm;
	}
	void bill(int qt,float cost) {
		System.out.println("bill amt="+(cost*qt));
	}
    static Scanner sc=new Scanner (System.in);
	public static void main(String[] args) {
		System.out.println("Enter product id");
		int id=sc.nextInt();
		System.out.println("Enter product cost");
		float cost=sc.nextFloat();
		System.out.println("Enetr quantity");
		int qt=sc.nextInt();
		System.out.println("Enter product name");
		String nm=sc.next();
		product obj=new product();
		obj.setProid(id);
		obj.setProdcost(cost);
		obj.setProdnm(nm);
		product p=new product();
	p.bill(qt, cost);

}
}