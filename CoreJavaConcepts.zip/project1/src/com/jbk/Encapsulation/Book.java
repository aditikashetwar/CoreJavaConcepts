package com.jbk.Encapsulation;
public class Book {
	private int bookid;
	private float bookcost;
	private String bookname;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public float getBookcost() {
		return bookcost;
	}
	public void setBookcost(float bookcost) {
		this.bookcost = bookcost;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
}
