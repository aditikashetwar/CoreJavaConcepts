package com.jbk.Encapsulation;
import java.util.Scanner;
public class Bookpurchase {
static Scanner sc=new Scanner (System.in);
	public static void main(String[] args) {
		Book p=new Book();
		System.out.println("Enter Book id");
		int id=sc.nextInt();
		p.setBookid(id);
	System.out.println("Enter book cost");
	float cost=sc.nextFloat();
	p.setBookcost(cost);
	System.out.println("Enetr book name");
	String name=sc.next();
	System.out.println("Enter quantity");
	int qty=sc.nextInt();
	float bill=cost*qty;
	System.out.println("Bill Amount = "+bill);

	}

}
