package com.jbk.Encapsulation;

public class student {
	private int studid;
	private String studnm;

	public int getStudid() {
		return studid;
	}
	public void setStudid(int studid) {
		this.studid = studid;
	}
	public String getStudnm() {
		return studnm;
	}
	public void setStudnm(String studnm) {
		this.studnm = studnm;
	}
	public static void main(String[] args) {
		student s1=new student();
		s1.setStudid(101);
		s1.setStudnm("Aditi");
		System.out.println("Student Id= "+s1.studid);
		System.out.println("Student Name= "+s1.studnm);
		
		student s2=new student();
		s2.setStudid(102);
		s2.setStudnm("Aditya");
		System.out.println("Student Id= "+s2.studid);
		System.out.println("Student Name= "+s2.studnm);

	}

}
