package com.jbk.new_concept;
//program to print methods of class math
public class Mathmethod_demo {

	public static void main(String[] args) {
		System.out.println("power="+Math.pow(2.0, 3.0));
		System.out.println("Celing method="+Math.ceil(2.35));
		System.out.println("Floor method="+Math.floor(2.35));
		System.out.println("Square root="+Math.sqrt(64.0));
		System.out.println("Maximum="+Math.max(2.43,3.98));
		

	}

}
