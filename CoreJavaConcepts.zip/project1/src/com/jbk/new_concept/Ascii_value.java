package com.jbk.new_concept;

public class Ascii_value {

	public static void main(String[] args) {
		int a=10;
		char ch='h';
		int sum=a+ch;
		System.out.println("sum= "+sum);

	}

}
