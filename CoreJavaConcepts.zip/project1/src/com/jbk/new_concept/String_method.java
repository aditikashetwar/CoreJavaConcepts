package com.jbk.new_concept;
import java.util.Scanner;
public class String_method {
//program to use method of string class
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String s=sc.next();
		System.out.println("uppercase="+s.toUpperCase());
		System.out.println("lowercase="+s.toLowerCase());
		System.out.println("index of that position="+s.indexOf('e'));
		System.out.println("equals="+s.equals("well"));
		System.out.println("length="+s.length());
		System.out.println("subsring="+s.substring(2));
		System.out.println("concatination of 2 string="+s.concat("all"));
		
		

	}

}
