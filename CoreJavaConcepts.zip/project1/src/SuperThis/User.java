package SuperThis;
//method overridding
public class User extends Homepage{
	public void msg(String s) {
		String s1="Welcome User-";
		System.out.println(s1+s);
	}


	public static void main(String[] args) {
		Homepage h=new Homepage();
		h.msg("jbk");
		User u=new User();
		u.msg("Aditi");
	}

}
