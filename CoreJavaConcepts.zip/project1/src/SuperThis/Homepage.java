package SuperThis;

public class Homepage {
	public void msg(String s) {
		System.out.println(s);
	}

}
