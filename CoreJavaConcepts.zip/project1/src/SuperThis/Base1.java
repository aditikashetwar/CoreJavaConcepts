package SuperThis;

public class Base1 {
	protected int a;
	public void setData() {
		a=10;
	}

}
