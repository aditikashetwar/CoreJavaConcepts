package SuperThis;

public class Derived extends Base1{
	private int a;
	public void setData1() {
		a=100;
	}
	public void disp() {
		System.out.println("Base class="+super.a);//it is used to refer base class
		System.out.println("Derived class="+this.a);//it refers current object
	}

	public static void main(String[] args) {
	Derived obj= new Derived();
	obj.setData();
    obj.setData1();
    obj.disp();

	}

}
